<?php
$class_r[1]=Array('classid'=>1,
'bclassid'=>0,
'classname'=>'科技服务',
'sonclass'=>'',
'featherclass'=>'',
'islast'=>1,
'classpath'=>'kjfw',
'classtype'=>'.html',

'down_num'=>1,
'online_num'=>1,
'islist'=>1,
'tid'=>1,
'tbname'=>'news',
'modid'=>1,
'lencord'=>25,
'newstempid'=>2,
'listtempid'=>2,

'filetype'=>'.html',


'checked'=>1,
'bname'=>'科技服务',

'reorder'=>'newstime DESC',
'dtlisttempid'=>2);
$class_r[2]=Array('classid'=>2,
'bclassid'=>0,
'classname'=>'知识产权',
'sonclass'=>'',
'featherclass'=>'',
'islast'=>1,
'classpath'=>'zscq',
'classtype'=>'.html',

'down_num'=>1,
'online_num'=>1,
'islist'=>1,
'tid'=>1,
'tbname'=>'news',
'modid'=>1,
'lencord'=>25,
'newstempid'=>2,
'listtempid'=>2,

'filetype'=>'.html',


'checked'=>1,
'bname'=>'知识产权',

'reorder'=>'newstime DESC',
'dtlisttempid'=>2);
$class_r[3]=Array('classid'=>3,
'bclassid'=>0,
'classname'=>'体系认证',
'sonclass'=>'',
'featherclass'=>'',
'islast'=>1,
'classpath'=>'txrz',
'classtype'=>'.html',

'down_num'=>1,
'online_num'=>1,
'islist'=>1,
'tid'=>1,
'tbname'=>'news',
'modid'=>1,
'lencord'=>25,
'newstempid'=>2,
'listtempid'=>2,

'filetype'=>'.html',


'checked'=>1,
'bname'=>'体系认证',

'reorder'=>'newstime DESC',
'dtlisttempid'=>2);
$class_r[4]=Array('classid'=>4,
'bclassid'=>0,
'classname'=>'新闻中心',
'sonclass'=>'|15|16|17|',
'featherclass'=>'',
'islast'=>0,
'classpath'=>'xwzx',
'classtype'=>'.html',

'down_num'=>1,
'online_num'=>1,
'islist'=>1,
'tid'=>1,
'tbname'=>'news',
'modid'=>1,
'lencord'=>25,
'reorder'=>'newstime DESC',
'listtempid'=>1,
'dtlisttempid'=>1);
$class_r[5]=Array('classid'=>5,
'bclassid'=>0,
'classname'=>'客户见证',
'sonclass'=>'|13|14|',
'featherclass'=>'',
'islast'=>0,
'classpath'=>'khjz',
'classtype'=>'.html',

'down_num'=>1,
'online_num'=>1,
'islist'=>2,
'tid'=>1,
'tbname'=>'news',
'modid'=>1,
'lencord'=>25,
'reorder'=>'newstime DESC',
'listtempid'=>1,
'dtlisttempid'=>1);
$class_r[6]=Array('classid'=>6,
'bclassid'=>0,
'classname'=>'关于我们',
'sonclass'=>'|7|8|9|10|11|12|',
'featherclass'=>'',
'islast'=>0,
'classpath'=>'gywm',
'classtype'=>'.html',

'down_num'=>1,
'online_num'=>1,
'islist'=>2,
'tid'=>1,
'tbname'=>'news',
'modid'=>1,
'lencord'=>25,
'reorder'=>'newstime DESC',
'listtempid'=>1,
'dtlisttempid'=>1);
$class_r[7]=Array('classid'=>7,
'bclassid'=>6,
'classname'=>'企业介绍',
'sonclass'=>'',
'featherclass'=>'|6|',
'islast'=>1,
'classpath'=>'gywm/qyjs',
'classtype'=>'.html',

'down_num'=>1,
'online_num'=>1,
'islist'=>0,
'tid'=>1,
'tbname'=>'news',
'modid'=>1,
'lencord'=>25,
'newstempid'=>1,
'listtempid'=>1,

'filetype'=>'.html',


'checked'=>1,
'bname'=>'企业介绍',

'reorder'=>'newstime DESC',
'dtlisttempid'=>1);
$class_r[8]=Array('classid'=>8,
'bclassid'=>6,
'classname'=>'精英团队',
'sonclass'=>'',
'featherclass'=>'|6|',
'islast'=>1,
'classpath'=>'gywm/jytd',
'classtype'=>'.html',

'down_num'=>1,
'online_num'=>1,
'islist'=>0,
'tid'=>1,
'tbname'=>'news',
'modid'=>2,
'lencord'=>25,
'newstempid'=>1,
'listtempid'=>4,

'filetype'=>'.html',


'checked'=>1,
'bname'=>'精英团队',

'reorder'=>'newstime DESC',
'dtlisttempid'=>4);
$class_r[9]=Array('classid'=>9,
'bclassid'=>6,
'classname'=>'公司环境',
'sonclass'=>'',
'featherclass'=>'|6|',
'islast'=>1,
'classpath'=>'gywm/gshj',
'classtype'=>'.html',

'down_num'=>1,
'online_num'=>1,
'islist'=>0,
'tid'=>1,
'tbname'=>'news',
'modid'=>2,
'lencord'=>25,
'newstempid'=>1,
'listtempid'=>3,

'filetype'=>'.html',


'checked'=>1,
'bname'=>'公司环境',

'reorder'=>'newstime DESC',
'dtlisttempid'=>3);
$class_r[10]=Array('classid'=>10,
'bclassid'=>6,
'classname'=>'荣誉资质',
'sonclass'=>'',
'featherclass'=>'|6|',
'islast'=>1,
'classpath'=>'gywm/ryzz',
'classtype'=>'.html',

'down_num'=>1,
'online_num'=>1,
'islist'=>0,
'tid'=>1,
'tbname'=>'news',
'modid'=>2,
'lencord'=>25,
'newstempid'=>1,
'listtempid'=>3,

'filetype'=>'.html',


'checked'=>1,
'bname'=>'荣誉资质',

'reorder'=>'newstime DESC',
'dtlisttempid'=>3);
$class_r[11]=Array('classid'=>11,
'bclassid'=>6,
'classname'=>'合作伙伴',
'sonclass'=>'',
'featherclass'=>'|6|',
'islast'=>1,
'classpath'=>'gywm/hzhb',
'classtype'=>'.html',

'down_num'=>1,
'online_num'=>1,
'islist'=>0,
'tid'=>1,
'tbname'=>'news',
'modid'=>2,
'lencord'=>25,
'newstempid'=>1,
'listtempid'=>5,

'filetype'=>'.html',


'checked'=>1,
'bname'=>'合作伙伴',

'reorder'=>'newstime DESC',
'dtlisttempid'=>5);
$class_r[12]=Array('classid'=>12,
'bclassid'=>6,
'classname'=>'联系我们',
'sonclass'=>'',
'featherclass'=>'|6|',
'islast'=>1,
'classpath'=>'gywm/lxwm',
'classtype'=>'.html',

'down_num'=>1,
'online_num'=>1,
'islist'=>0,
'tid'=>1,
'tbname'=>'news',
'modid'=>1,
'lencord'=>25,
'newstempid'=>1,
'listtempid'=>1,

'filetype'=>'.html',


'checked'=>1,
'bname'=>'联系我们',

'reorder'=>'newstime DESC',
'dtlisttempid'=>1);
$class_r[13]=Array('classid'=>13,
'bclassid'=>5,
'classname'=>'成功案例',
'sonclass'=>'',
'featherclass'=>'|5|',
'islast'=>1,
'classpath'=>'khjz/cgal',
'classtype'=>'.html',

'down_num'=>1,
'online_num'=>1,
'islist'=>0,
'tid'=>1,
'tbname'=>'news',
'modid'=>1,
'lencord'=>25,
'newstempid'=>1,
'listtempid'=>2,

'filetype'=>'.html',


'checked'=>1,
'bname'=>'成功案例',

'reorder'=>'newstime DESC',
'dtlisttempid'=>2);
$class_r[14]=Array('classid'=>14,
'bclassid'=>5,
'classname'=>'客户评价',
'sonclass'=>'',
'featherclass'=>'|5|',
'islast'=>1,
'classpath'=>'khjz/khpj',
'classtype'=>'.html',

'down_num'=>1,
'online_num'=>1,
'islist'=>0,
'tid'=>1,
'tbname'=>'news',
'modid'=>1,
'lencord'=>25,
'newstempid'=>1,
'listtempid'=>2,

'filetype'=>'.html',


'checked'=>1,
'bname'=>'客户评价',

'reorder'=>'newstime DESC',
'dtlisttempid'=>2);
$class_r[15]=Array('classid'=>15,
'bclassid'=>4,
'classname'=>'公司新闻',
'sonclass'=>'',
'featherclass'=>'|4|',
'islast'=>1,
'classpath'=>'xwzx/gsxw',
'classtype'=>'.html',

'down_num'=>1,
'online_num'=>1,
'islist'=>0,
'tid'=>1,
'tbname'=>'news',
'modid'=>1,
'lencord'=>25,
'newstempid'=>1,
'listtempid'=>1,

'filetype'=>'.html',


'checked'=>1,
'bname'=>'公司新闻',

'reorder'=>'newstime DESC',
'dtlisttempid'=>1);
$class_r[16]=Array('classid'=>16,
'bclassid'=>4,
'classname'=>'行业动态',
'sonclass'=>'',
'featherclass'=>'|4|',
'islast'=>1,
'classpath'=>'xwzx/xydt',
'classtype'=>'.html',

'down_num'=>1,
'online_num'=>1,
'islist'=>0,
'tid'=>1,
'tbname'=>'news',
'modid'=>1,
'lencord'=>25,
'newstempid'=>1,
'listtempid'=>1,

'filetype'=>'.html',


'checked'=>1,
'bname'=>'行业动态',

'reorder'=>'newstime DESC',
'dtlisttempid'=>1);
$class_r[17]=Array('classid'=>17,
'bclassid'=>4,
'classname'=>'常见问题',
'sonclass'=>'',
'featherclass'=>'|4|',
'islast'=>1,
'classpath'=>'xwzx/cjwt',
'classtype'=>'.html',

'down_num'=>1,
'online_num'=>1,
'islist'=>0,
'tid'=>1,
'tbname'=>'news',
'modid'=>1,
'lencord'=>25,
'newstempid'=>1,
'listtempid'=>1,

'filetype'=>'.html',


'checked'=>1,
'bname'=>'常见问题',

'reorder'=>'newstime DESC',
'dtlisttempid'=>1);
?>