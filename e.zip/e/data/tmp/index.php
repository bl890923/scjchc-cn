<?php
if(!defined('InEmpireCMS'))
{
	exit();
}
?><!DOCTYPE html>
<html>
<!-- head -->
<head>
<meta charset="UTF-8">
<meta name="renderer" content="webkit">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta property="og:image" content="/static/image/9fe2f40936d1bb78.jpg">
<title><?=$public_r[sitename]?></title>
<meta name="keywords" content="">
<meta name="description" content="首页描述">
<link type="text/css" rel="stylesheet" href="/static/css/Common.css">
<link type="text/css" rel="stylesheet" href="/static/css/animate.css">
<link type="text/css" rel="stylesheet" href="/static/css/Index.css">
<script type="text/javascript" src="/static/js/1.9.1jquery.min.js"></script>
<script type="text/javascript" src="/static/js/common.js"></script>
<script type="text/javascript" src="/static/js/wow.js"></script>
<script type="text/javascript" src="/static/js/index.js"></script>
</head>
<body>

<!-- header --> 

<div class="top-wrap">
<div class="wrapper">
<div class="top-menu">
<ul>
<li>
<a href="javascript:;">网站地图</a></li>
<li>
<a href="javascript:addBookmark()">收藏本站</a></li>
<li>
<a href="/gywm/lxwm/">联系方式</a></li>
</ul>
</div>
<div class="welcome">欢迎来到<?=$public_r[sitename]?>官方网站！</div>
</div>
</div>


<div class="header-wrap">
<div class="wrapper">
<div class="logo"> 
<a href="/" title="精诚合创"> <img src="/static/picture/logo.png" alt="精诚合创"> </a> </div>
<div class="slogan">
<h2>高新企业认定服务商</h2>
<p>更擅长处理疑难项目</p>
</div>
<div class="tel">
<dl>
<dt>全国服务热线</dt>
<dd>
<?=$public_r[fwrx]?>
</dd>
</dl>
</div>
</div>
</div>


<div class="nav" id="nav">
<div class="wrapper">
<ul class="nav-list" id="navBox">
<li>
<a href="/">网站首页</a></li>
<li mark='1' px='2'> 
<a href="javascript:;">科技服务</a>
<div class="dorpDown">
<div class="wrapper"> 
<?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsLoopBq(1,20,0,0,'','newstime ASC');
if($ecms_bq_sql){
while($bqr=$empire->fetch($ecms_bq_sql)){
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
<a href="<?=$bqsr['titleurl']?>"><?=$bqr['title']?></a>
<?php
}
}
?>
</div>
</div>
</li>
<li mark='2' px='3'> 
<a href="javascript:;">知识产权</a>
<div class="dorpDown">
<div class="wrapper"> 
<?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsLoopBq(2,20,0,0,'','newstime ASC');
if($ecms_bq_sql){
while($bqr=$empire->fetch($ecms_bq_sql)){
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
<a href="<?=$bqsr['titleurl']?>"><?=$bqr['title']?></a>
<?php
}
}
?>
</div>
</div>
</li>
<li mark='3' px='4'> 
<a href="javascript:;">体系认证</a>
<div class="dorpDown">
<div class="wrapper"> 
<?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsLoopBq(3,5,0,0,'','newstime ASC');
if($ecms_bq_sql){
while($bqr=$empire->fetch($ecms_bq_sql)){
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
<a href="<?=$bqsr['titleurl']?>"><?=$bqr['title']?></a>
<?php
}
}
?>
</div>
</div>
</li>
<li mark='5' px='6'> 
<a href="/khjz/cgal/">客户见证</a>
<div class="dorpDown">
<div class="wrapper"> 
<a href="/khjz/khpj/">客户评价</a> 
<a href="/khjz/cgal/">成功案例</a> 
</div>
</div>
</li>
<li mark='4' px='7'> 
<a href="/xwzx/">新闻中心</a>
<div class="dorpDown">
<div class="wrapper"> 
<a href="/xwzx/gsxw/">公司新闻</a> 
<a href="/xwzx/xydt/">行业动态</a> 
<a href="/xwzx/cjwt/">常见问题</a> 
</div>
</div>
</li>
<li mark='6' px='8'> 
<a href="/gywm/qyjs/">关于我们</a>
<div class="dorpDown">
<div class="wrapper"> 
<a href="/gywm/qyjs/">企业介绍</a> 
<a href="/gywm/jytd/">精英团队</a> 
<a href="/gywm/gshj/">公司环境</a> 
<a href="/gywm/ryzz/">荣誉资质</a> 
<a href="/gywm/hzhb/">合作伙伴</a> 
<a href="/gywm/lxwm/">联系我们</a> 
</div>
</div>
</li>
<li mark='12' px='9'> 
<a href="/gywm/lxwm/">联系我们</a> 
</li>
</ul>
</div>
</div>


<script type="text/javascript">
var sid = '4,7';
headinit(sid);
</script> 


<!-- end nav --> 


<!-- banner-->
<div class="banner">
<div class="bd">
<ul>
<li> <a href="javascript:;" title="精诚合创一个更擅长处理疑难问题的高新企业认定服务商" style="background:url(/static/image/8d29b23f4dd983bd.jpg) no-repeat center"></a> </li>
<li> <a href="javascript:;" title="精诚合创10年专业重新梳理高新企业认定条件" style="background:url(/static/image/52eadf8a079c6387.jpg) no-repeat center"></a> </li>
<li> <a href="javascript:;" title="在成都申报高新企业认定，就找精诚合创" style="background:url(/static/image/82f14f7d9aa85a5f.jpg) no-repeat center"></a> </li>
<li> <a href="javascript:;" title="精诚合创更擅长成都高新技术企业认定申报" style="background:url(/static/image/b9b3e6e1ff456d9c.jpg) no-repeat center"></a> </li>
</ul>
</div>
<div class="hd">
<ul>
</ul>
</div>
<div class="arrow">
<div class="prev"></div>
<div class="next"></div>
</div>
<div class="linksBtn"> <a href="javascript:;"><span class="btn-wave">科技服务</span></a> <a href="javascript:;"><span class="btn-wave">知识产权</span></a> <a href="javascript:;"><span class="btn-wave">体系认证</span></a> </div>
</div>
<!-- end banner --> 

<!-- 搜索 1-->
<div class="search">
<div class="wrapper">
<div class="keyword"> <strong>热门搜索：</strong> <a href="javascript:;">知识产权贯标</a> <a href="javascript:;">高新企业认定条件</a> <a href="javascript:;">高新企业申报流程</a> <a href="javascript:;">高新企业认定</a> </div>
<div class="search-form">
<form action="/search/index.html">
<input class="text" type="text" name="word" value="请输入关键词" onblur="if(this.value==''){this.value='请输入关键词'}" onfocus="if(this.value=='请输入关键词'){this.value=''}">
<button type="submit" name="submit"></button>
</form>
</div>
</div>
</div>
<!-- end 搜索 --> 

<!-- 动态 -->
<div class="message">
<div class="wrapper">
<div class="wrap-title">
<h2>高新企业认定<strong>动态</strong></h2>
<p>及时了解成都各区的高新企业申报政策</p>
</div>
<div class="pic"><img src="/static/picture/message.png" alt="成都各区高新企业申请"></div>
<div class="text">
<div class="message-marquee">
<ul>
<li><span class="area">【武侯区】</span><span class="name">成都市睿唯科技有限公司</span><span class="state">签订高新认定</span></li>
<li><span class="area">【武侯区】</span><span class="name">成都市百川声电子有限公司</span><span class="state">签订高新认定</span></li>
<li><span class="area">【锦江区】</span><span class="name">成都衡伟环境技术有限公司</span><span class="state">签订高新认定</span></li>
<li><span class="area">【锦江区】</span><span class="name">成都市诚悅电子有限公司</span><span class="state">设备补贴</span></li>
<li><span class="area">【武侯区】</span><span class="name">成都市欣博莱特科技有限公司</span><span class="state">知识产权</span></li>
<li><span class="area">【天府新区】</span><span class="name">成都市智化电科技有限公司</span><span class="state">实用新型</span></li>
<li><span class="area">【武侯区】</span><span class="name">成都市利智科技有限公司</span><span class="state">签订高新认定</span></li>
<li><span class="area">【武侯区】</span><span class="name">成都市鸿佳盛科技有限公司</span><span class="state">签订高新认定</span></li>
<li><span class="area">【武侯区】</span><span class="name">成都市同创顺成型技术有限公司</span><span class="state">签订高新认定</span></li>
<li><span class="area">【锦江区】</span><span class="name">成都市友林电子有限公司</span><span class="state">展会补贴</span></li>
<li><span class="area">【青羊区】</span><span class="name">成都市金合发五金科技有限公司</span><span class="state">设备补贴</span></li>
<li><span class="area">【龙泉驿区】</span><span class="name">成都市创锐芯电子有限公司</span><span class="state">签订高新认定</span></li>
<li><span class="area">【武侯区】</span><span class="name">成都市家惠宝智能家居有限公司</span><span class="state">签订高新认定</span></li>
<li><span class="area">【锦江区】</span><span class="name">成都市一图智能科技有限公司</span><span class="state">签订高新认定</span></li>
<li><span class="area">【青白江区】</span><span class="name">成都市亚泰伟业科技有限公司</span><span class="state">研发补贴</span></li>
<li><span class="area">【锦江区】</span><span class="name">成都市锦昊辉实业发展有限公司</span><span class="state">新入库支持</span></li>
<li><span class="area">【武侯区】</span><span class="name">祥龙科技（成都）有限公司</span><span class="state">签订高新认定</span></li>
<li><span class="area">【锦江区】</span><span class="name">成都市能安消防装饰工程设备有限公司</span><span class="state">签订高新认定</span></li>
<li><span class="area">【锦江区】</span><span class="name">成都市大诚行汽车发展有限公司</span><span class="state">贷款补贴</span></li>
<li><span class="area">【武侯区】</span><span class="name">成都市三德盈电子有限公司</span><span class="state">设备补贴</span></li>
</ul>
</div>
<div class="btnBox"> <a href="javascript:;" rel="nofollow" class="fl btn-wave">找精诚合创分析</a> <a href="javascript:;" class="fr btn-wave">疑难解答</a> </div>
</div>
</div>
</div>
<!-- end 动态 --> 

<!-- 认证原因 -->
<div class="cause">
<div class="wrapper">
<div class="wrap-title">
<h2>为什么要认证<strong>高新?</strong></h2>
<p>不仅仅只是政府补助，更多的是机遇与优先权</p>
</div>
<div class="cause-list">
<div class="item">
<div class="hd">减税</div>
<div class="bd">
<h3>企业所得税税率减免10%</h3>
<p>被认定为高新技术的企业，其企业所得税税率为15%，比普通企业的税率低10%，意味着税额可以减少40%</p>
</div>
</div>
<div class="item">
<div class="hd">补贴</div>
<div class="bd">
<h3>享有百万以上政府扶持及补贴</h3>
<p>通过高新认证的企业可获得地方的直接资金奖励，可享有高达百万以上的政府项目扶持及补贴</p>
</div>
</div>
<div class="item">
<div class="hd">上市</div>
<div class="bd">
<h3>企业优先上市</h3>
<p>优先审核批准符合上市条件的股份制高新技术企业股票上市；高新技术企业也是上市的基本条件之一</p>
</div>
</div>
<div class="item">
<div class="hd">形象</div>
<div class="bd">
<h3>促进科技企业转型+品牌形象</h3>
<p>响应国家发展战略，调整企业产业结构，自主创新；可以树立良好的企业形象，吸引科技人才</p>
</div>
</div>
</div>
</div>
</div>
<!-- end 认证原因 --> 

<!-- 困扰 -->
<div class="worry">
<div class="wrapper">
<div class="wrap-title">
<h2>你是否有以下<strong>困扰?</strong></h2>
<p>高新企业认定是企业向上发展的必经之路</p>
</div>
<div class="worry-list">
<div class="item wow fadeInUp animated" data-wow-delay="0.25s">
<p>自己申请太麻烦，预约排队耗时间？</p>
</div>
<div class="item wow fadeInUp animated" data-wow-delay="0.5s">
<p>申请流程不清楚，资料收集又费力？</p>
</div>
<div class="item wow fadeInUp animated" data-wow-delay="1s">
<p>担心委托给了不良第三方，服务无保证？</p>
</div>
<div class="item wow fadeInUp animated" data-wow-delay="1.5s">
<p>干拖着一等再等，错过了一大堆政府补贴？</p>
</div>
<div class="item wow fadeInUp animated" data-wow-delay="2s">
<p>申请要求不定期更新，通过率越来越低？</p>
</div>
</div>
</div>
</div>
<!-- end 困扰 --> 

<!-- 优势 -->
<div class="youshi">
<div class="wrapper">
<div class="hd">
<div class="tit"><img src="/static/picture/ys_tit.png" alt="四大优势"></div>
<h2>精诚合创<br>
让你无后顾之忧</h2>
<p>Know the top<br>
four advantages for<br>
you to worry about</p>
</div>
<div class="bd">
<div class="item odd">
<dl>
<dt><img src="/static/picture/num01.png" alt="01"></dt>
<dd>
<h3>先成功，后收费，风险我来担</h3>
<p>没有人能担保百分百的通过率，因为世界在变，明天无法预知。精诚合创能做的，只是帮你承担风险。</p>
</dd>
</dl>
</div>
<div class="item even">
<dl>
<dt><img src="/static/picture/num02.png" alt="02"></dt>
<dd>
<h3>申请流程微信直播，进度实时掌握</h3>
<p>微信全程直播办理流程，申请进度到哪了，实时掌握，专业人员一对一跟踪项目进度。</p>
</dd>
</dl>
</div>
<div class="item odd">
<dl>
<dt><img src="/static/picture/num03.png" alt="03"></dt>
<dd>
<h3>明码标价，价格透明心中有数</h3>
<p>把价格写进合同里，白纸黑字价格透明，申请成功不会另收费用。</p>
</dd>
</dl>
</div>
<div class="item even">
<dl>
<dt><img src="/static/picture/num04.png" alt="04"></dt>
<dd>
<h3>SSS级资料保密系统，10年0泄露</h3>
<p>精诚合创原创资料保密系统，分段式保存客户资料：S级、SS级、SSS级分开储存保管，10年保持0泄露记录。</p>
</dd>
</dl>
</div>
</div>
</div>
</div>
<!-- end 优势 --> 

<!-- 服务 -->
<div class="service">
<div class="wrapper">
<div class="wrap-title">
<p>项目申报需要其他资质怎么办？</p>
<h2>精诚合创一站式配套服务帮你<strong>全部解决</strong></h2>
</div>
<div class="service-list"> <a class="item" href="javascript:;"> <i><img src="/static/picture/f5a6beae574433c9.png" alt="版权登记"></i> <span>版权登记</span>
<p>理清财务账目，快速通过高新</p>
</a> <a class="item" href="javascript:;"> <i><img src="/static/picture/de9ce0ddf13341f7.png" alt="专利申请"></i> <span>专利申请</span>
<p>快速申请，满足高新条件</p>
</a> <a class="item" href="javascript:;"> <i><img src="/static/picture/2ebab77d8d83d572.png" alt="财税服务"></i> <span>财税服务</span>
<p>理清财务账目，快速通过高新</p>
</a> <a class="item" href="javascript:;"> <i><img src="/static/picture/a03cd69924b32a24.png" alt="商标注册"></i> <span>商标注册</span>
<p>多位资深法律顾问为您服务</p>
</a> <a class="item" href="javascript:;"> <i><img src="/static/picture/690011ed35bcb46b.png" alt="其他补贴"></i> <span>其他补贴</span>
<p>发现更多政府支持政策</p>
</a> </div>
</div>
</div>
<!-- end 服务 --> 

<!-- 精英团队 -->
<div class="team">
<div class="wrapper">
<div class="wrap-title white">
<h2><a href="javascript:;"><strong>精诚合创精英团队</strong></a></h2>
<p>解决了70多个疑难项目</p>
</div>
<div class="team-slide">
<div class="team-list">
<div class="bd">
<div class="team-item">
<div class="leftCon">
<div class="pic"> <a href="javascript:;" title="赵子扬"><img src="/static/picture/af67e6108ffd406d.jpg" alt="赵子扬"></a> </div>
<div class="text"> <a href="javascript:;" rel="nofollow">找他<br>
咨询</a> <strong>赵子扬</strong>
<p>多年认证经验</p>
</div>
</div>
<div class="rightCon">
<div class="tit">TA解决的疑难项目</div>
<div class="text">
<dl>
<dt><a href="javascript:;">成都市***实业有限公司</a></dt>
<dd><a href="javascript:;">梳理中发现，该公司科技成果转化项得分很低，科技成果转化附件材料混乱、装订无序，与成果转化汇总表中所列不一致，拉低整体分数，导致未顺利通过。</a></dd>
</dl>
<dl>
<dt><a href="javascript:;">成都市***宁科技有限公司</a></dt>
<dd><a href="javascript:;">参考第一次申报评分，以及第一次申报的具体材料，发现此前申报中，写资料的人没抓住核心技术，对企业核心产品理解不到位，表述有偏差，最终导致未通过。</a></dd>
</dl>
<dl>
<dt><a href="javascript:;">成都市***网络科技有限公司</a></dt>
<dd><a href="javascript:;">该公司第一次递交未通过，后经精诚合创梳理发现，高新领域选择错误，导致一系列反应。而且分析后财务数据填写亦有误，资料不相符，最终导致评分较低。</a></dd>
</dl>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<!-- end 精英团队 --> 

<!-- 服务企业 -->
<div class="customer">
<div class="wrapper">
<div class="wrap-title">
<h2><a href="/khjz/cgal/"><b>精诚合创累计服务</b><strong>1000多家企业</strong></a></h2>
<p>更多疑难客户的信赖之选</p>
</div>
<div class="customer-list"> 

<?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsLoopBq(13,6,0,1);
if($ecms_bq_sql){
while($bqr=$empire->fetch($ecms_bq_sql)){
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
<a href="<?=$bqsr['titleurl']?>" class="item">
<div class="pic"><img src="<?=$bqr['titlepic']?>" alt="<?=$bqr['title']?>"></div>
<div class="text"> <span><?=$bqr['title']?></span>
<p><?=$bqr['ftitle']?></p>
</div>
</a> 
<?php
}
}
?>

 </div>
</div>
</div>
<!-- end 服务企业 --> 

<!-- 服务流程 -->
<div class="process">
<div class="wrapper">
<div class="wrap-title">
<h2>精诚合创如何<strong>为您服务？</strong></h2>
<p>从资料收集到进度跟踪全由我们解决，让您足不出户查收申报回执</p>
</div>
<div class="process-list">
<div class="item">
<div class="pic"><img src="/static/picture/process01.png" alt="咨询沟通"></div>
<div class="text"><strong>咨询</strong>沟通</div>
</div>
<div class="item">
<div class="pic"><img src="/static/picture/process02.png" alt="评估分析"></div>
<div class="text"><strong>评估</strong>分析</div>
</div>
<div class="item">
<div class="pic"><img src="/static/picture/process03.png" alt="签约合作"></div>
<div class="text"><strong>签约</strong>合作</div>
</div>
<div class="item">
<div class="pic"><img src="/static/picture/process04.png" alt="资料收集"></div>
<div class="text"><strong>资料</strong>收集</div>
</div>
<div class="item">
<div class="pic"><img src="/static/picture/process05.png" alt="申请递交"></div>
<div class="text"><strong>申请</strong>递交</div>
</div>
<div class="item">
<div class="pic"><img src="/static/picture/process06.png" alt="跟踪进度"></div>
<div class="text"><strong>跟踪</strong>进度</div>
</div>
</div>
</div>
</div>
<!-- end 服务流程 --> 

<!-- 表单 -->
<div class="indexForm">
<div class="wrapper">
<div class="leftCon">
<div class="hd">
<div class="tel">
<ul>
<li class="t1"> <span>全国免费热线：</span> <strong>
<?=$public_r[fwrx]?>
</strong> </li>
<li class="t2"> <span>精诚合创营销专线：</span> <strong>
<?=$public_r[lxdh]?>
</strong> </li>
</ul>
</div>
<div class="tit"> <strong>在线留言</strong>/<em>Online message</em> </div>
</div>
<div class="bd">
<ul>
<li>
<input type="text" value="对接人" id="txtContact" onfocus="if(this.value=='对接人'){this.value=''}" onblur="if(this.value==''){this.value='对接人'}">
</li>
<li>
<input type="text" value="联系电话" id="txtMobile" onfocus="if(this.value=='联系电话'){this.value=''}" onblur="if(this.value==''){this.value='联系电话'}">
</li>
<li><a href="javascript:;" class="btn btn-wave" onclick="sendLeaveword_Index(this);">提交给精诚合创</a></li>
</ul>
</div>
</div>
<div class="rightCon">
<div class="pic"><img src="/static/picture/6a68b8be71dc3846.png" alt="高新技术企业申请二维码"></div>
<div class="text">
<p>关注精诚合创官方微信<br>
及时了解政策更新</p>
</div>
</div>
</div>
</div>
<!-- end 表单 --> 

<!-- 政策资讯 -->
<div class="news">
<div class="wrapper">
<div class="wrap-title">
<h2><a href="javascript:;"><strong>政策/资讯</strong></a></h2>
<p>汇聚行业方向性资讯与新闻</p>
</div>
<div class="news-inner">
<div class="news-item">
<div class="tit"> <a href="/xwzx/gsxw/">More+</a> <strong>公司新闻</strong> </div>
<div class="pic"> <a href="/xwzx/gsxw/"> <img src="/static/picture/news-item1.jpg" alt="公司新闻"> </a> </div>
<div class="news-list">
<ul>
<?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsLoopBq(15,5,0,0);
if($ecms_bq_sql){
while($bqr=$empire->fetch($ecms_bq_sql)){
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
<li><a href="<?=$bqsr['titleurl']?>"><?=$bqr['title']?></a> </li>
<?php
}
}
?>
</ul>
</div>
</div>
<div class="news-item">
<div class="tit"> <a href="/xwzx/xydt/">More+</a> <strong>行业动态</strong> </div>
<div class="pic"> <a href="/xwzx/xydt/"> <img src="/static/picture/news-item2.jpg" alt="行业动态"> </a> </div>
<div class="news-list">
<ul>
<?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsLoopBq(16,5,0,0);
if($ecms_bq_sql){
while($bqr=$empire->fetch($ecms_bq_sql)){
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
<li><a href="<?=$bqsr['titleurl']?>"><?=$bqr['title']?></a> </li>
<?php
}
}
?>
</ul>
</div>
</div>
<div class="news-item">
<div class="tit"> <a href="/xwzx/cjwt/">More+</a> <strong>常见问题</strong> </div>
<div class="pic"> <a href="/xwzx/cjwt/"> <img src="/static/picture/news-item3.jpg" alt="常见问题"> </a> </div>
<div class="news-list">
<ul>
<?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsLoopBq(17,5,0,0);
if($ecms_bq_sql){
while($bqr=$empire->fetch($ecms_bq_sql)){
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
<li><a href="<?=$bqsr['titleurl']?>"><?=$bqr['title']?></a> </li>
<?php
}
}
?>
</ul>
</div>
</div>
</div>
</div>
</div>
<!-- end 政策资讯 --> 

<!-- 合作机构 -->
<div class="partner">
<div class="wrapper">
<div class="wrap-title">
<h2><a href="/gywm/hzhb/"><b>与多个机构合作，让申报流程</b><strong>更顺畅</strong></a></h2>
<p>精诚合创，更擅长成都本地科技项目申报</p>
</div>
<div class="partner-list">
<ul>

<?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsLoopBq(11,10,0,1);
if($ecms_bq_sql){
while($bqr=$empire->fetch($ecms_bq_sql)){
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
<li>
<div class="pic"> <a href="/gywm/hzhb/" rel="nofollow" title="<?=$bqr['title']?>"> <img src="<?=$bqr['titlepic']?>" alt="<?=$bqr['title']?>"> </a> </div>
<div class="text"><a href="/gywm/hzhb/"><?=$bqr['title']?></a></div>
</li>
<?php
}
}
?>


</ul>
</div>
</div>
</div>
<!-- end 合作机构 --> 

<!-- 友情链接 -->
<div class="flinks">
<div class="wrapper">
<div class="tit"> <a rel="nofollow">友情链接</a> <em>link</em> </div>
<div class="links-list">
<?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsLoopBq('select * from [!db.pre!]enewslink where 
checked=1 and classid=0 order by lid',20,24,0);
if($ecms_bq_sql){
while($bqr=$empire->fetch($ecms_bq_sql)){
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
<a href="<?=$bqr[lurl]?>"target="_blank"><?=$bqr[lname]?></a><?php
}
}
?>
</div>
</div>
</div>
<!-- end 友情链接 --> 

<!--尾部开始-->

<div class="footer">
<div class="wrapper">
<div class="foot-menu">
<dl>
<dt>
<a href="javascript:;">科技服务</a>
</dt>

<?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsLoopBq(1,4,0,0,'','newstime ASC');
if($ecms_bq_sql){
while($bqr=$empire->fetch($ecms_bq_sql)){
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
<dd><a href="<?=$bqsr['titleurl']?>"><?=$bqr['title']?></a></dd>
<?php
}
}
?>

</dl>
<dl>
<dt>
<a href="javascript:;">体系认证</a>
</dt>
<?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsLoopBq(3,4,0,0,'','newstime ASC');
if($ecms_bq_sql){
while($bqr=$empire->fetch($ecms_bq_sql)){
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
<dd><a href="<?=$bqsr['titleurl']?>"><?=$bqr['title']?></a></dd>
<?php
}
}
?>
</dl>
<dl>
<dt>
<a href="/gywm/qyjs/">知识产权</a>
</dt>
<?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsLoopBq(2,4,0,0,'','newstime ASC');
if($ecms_bq_sql){
while($bqr=$empire->fetch($ecms_bq_sql)){
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
<dd><a href="<?=$bqsr['titleurl']?>"><?=$bqr['title']?></a></dd>
<?php
}
}
?>
</dl>
</div>
<div class="foot-QR"> <img src="/static/picture/25086c2a9fdafb5c.jpg" alt="精诚合创高新技术企业认定微信扫码咨询"> <span>微信扫码咨询</span> </div>
<div class="foot-tel">
<dl>
<dt>全国免费热线：</dt>
<dd>
<?=$public_r[fwrx]?>
</dd>
</dl>
<dl>
<dt>精诚合创营销专线：</dt>
<dd>
<?=$public_r[lxdh]?>
</dd>
</dl>
</div>
</div>
</div>

<div class="copyright">
<div class="wrapper">
<div class="fl"> 

<a href="/gywm/qyjs/">企业介绍</a>
 
<a href="/gywm/lxwm/">联系我们</a>
 
<a href="/gywm/hzhb/">合作伙伴</a>
 
<a href="/xwzx/cjwt/">常见问题</a>

<a href="javascript:;">网站地图</a>


</div>
<div class="fr"> Copyright © 2028 <?=$public_r[sitename]?>，<a href="https://beian.miit.gov.cn/" rel="nofollow"><?=$public_r[icp]?></a>
， 技术支持:<a href="https://www.shunking.cn/">舜王科技</a>
 
</div>
</div>
</div>


<!-- 客服2 -->
<div class="y-kefu-box y-kefu-box02">
<div class="online-service"> <i class="icon"></i>
<p>在线<br>
客服</p>
<div class="online-service-infos more-infos"> <b class="right"> <i class="right-arrow1"></i> <i class="right-arrow2"></i> </b>
<div class="part01"> <i class="icon"></i>
<p>在线客服</p>
<span>服务时间：9：00-18：00</span> </div>
<div class="part02">
<ul class="clearfix" id="onlineKf">
<li>
<a href="javascript:;" title="点击这里给我发消息" rel="nofollow"><i class="icon"></i>客服小知</a>

</li>
</ul>
</div>
</div>
</div>
<div class="kf-mobile"> <i class="icon"></i>
<p>客服<br>
热线</p>
<div class="kf-mobile-infos more-infos"> <b class="right"> <i class="right-arrow1"></i> <i class="right-arrow2"></i> </b>
<div class="cont"> <i class="icon"></i>
<p>
<?=$public_r[fwrx]?>
</p>
<span>7*24小时客服服务热线</span> </div>
</div>
</div>
<div class="kf-weChat"> <i class="icon"></i>
<p>关注<br>
微信</p>
<div class="kf-weChat-infos more-infos"> <b class="right"> <i class="right-arrow1"></i> <i class="right-arrow2"></i> </b> <img src="/static/picture/6a68b8be71dc3846.png" alt="二维码">
<p>扫一扫，关注我们</p>
</div>
</div>
<div class="back-top" id="yBackTop"> <i class="icon"></i>
<p>回到<br>
顶部</p>
</div>
</div>
<script type="text/javascript">
$('.kf-mobile, .kf-weChat, .online-service').hover(function(){
$(this).children('div').stop().show().animate({right:'70px',opacity:1}, 400);
},function(){
$(this).children('div').stop().animate({right:'90px',opacity:0}, 400,function(){$(this).hide()});
})

//返回顶部
var yWin = $(window).scrollTop();
var isShow = true;
$(window).scroll(function(){
yWin = $(window).scrollTop();
console.log(yWin);
if(yWin > 500){
if(isShow){
isShow = false;
$('#yBackTop').show().animate({left:'0'}, 400);
} 
}
if(yWin < 500){
if(!isShow){
isShow = true;
$('#yBackTop').animate({left:'55px'}, 400,function(){$(this).hide();});
}
}
})
$('#yBackTop').on('click',function(){
$('html,body').animate({'scrollTop':0}, 800);
})
</script> 


<!--尾部结束-->

</body>
</html>