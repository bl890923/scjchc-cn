<?php
if(!defined('InEmpireCMS'))
{
	exit();
}
?><!DOCTYPE html>
<html>
<head>
<meta name="renderer" content="webkit">
<meta name="force-rendering" content="webkit">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>[!--pagetitle--] - <?=$public_r[sitename]?></title>
<meta name="keywords" content="[!--pagekey--]">
<meta name="description" content="[!--pagedes--]">
<link href="/static/css/Common.css" rel="stylesheet" type="text/css">
<link href="/static/css/Style.css" rel="stylesheet" type="text/css">
<link href="/static/css/fancybox.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="/static/js/1.9.1jquery.min.js"></script>
<script type="text/javascript" src="/static/js/common.js"></script>
<script type="text/javascript" src="/static/js/inpage.js"></script>
</head>

<body>

<!-- header --> 

<div class="top-wrap">
<div class="wrapper">
<div class="top-menu">
<ul>
<li>
<a href="javascript:;">网站地图</a></li>
<li>
<a href="javascript:addBookmark()">收藏本站</a></li>
<li>
<a href="/gywm/lxwm/">联系方式</a></li>
</ul>
</div>
<div class="welcome">欢迎来到<?=$public_r[sitename]?>官方网站！</div>
</div>
</div>


<div class="header-wrap">
<div class="wrapper">
<div class="logo"> 
<a href="/" title="精诚合创"> <img src="/static/picture/logo.png" alt="精诚合创"> </a> </div>
<div class="slogan">
<h2>高新企业认定服务商</h2>
<p>更擅长处理疑难项目</p>
</div>
<div class="tel">
<dl>
<dt>全国服务热线</dt>
<dd>
<?=$public_r[fwrx]?>
</dd>
</dl>
</div>
</div>
</div>


<div class="nav" id="nav">
<div class="wrapper">
<ul class="nav-list" id="navBox">
<li>
<a href="/">网站首页</a></li>
<li mark='1' px='2'> 
<a href="javascript:;">科技服务</a>
<div class="dorpDown">
<div class="wrapper"> 
<?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsLoopBq(1,20,0,0,'','newstime ASC');
if($ecms_bq_sql){
while($bqr=$empire->fetch($ecms_bq_sql)){
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
<a href="<?=$bqsr['titleurl']?>"><?=$bqr['title']?></a>
<?php
}
}
?>
</div>
</div>
</li>
<li mark='2' px='3'> 
<a href="javascript:;">知识产权</a>
<div class="dorpDown">
<div class="wrapper"> 
<?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsLoopBq(2,20,0,0,'','newstime ASC');
if($ecms_bq_sql){
while($bqr=$empire->fetch($ecms_bq_sql)){
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
<a href="<?=$bqsr['titleurl']?>"><?=$bqr['title']?></a>
<?php
}
}
?>
</div>
</div>
</li>
<li mark='3' px='4'> 
<a href="javascript:;">体系认证</a>
<div class="dorpDown">
<div class="wrapper"> 
<?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsLoopBq(3,5,0,0,'','newstime ASC');
if($ecms_bq_sql){
while($bqr=$empire->fetch($ecms_bq_sql)){
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
<a href="<?=$bqsr['titleurl']?>"><?=$bqr['title']?></a>
<?php
}
}
?>
</div>
</div>
</li>
<li mark='5' px='6'> 
<a href="/khjz/cgal/">客户见证</a>
<div class="dorpDown">
<div class="wrapper"> 
<a href="/khjz/khpj/">客户评价</a> 
<a href="/khjz/cgal/">成功案例</a> 
</div>
</div>
</li>
<li mark='4' px='7'> 
<a href="/xwzx/">新闻中心</a>
<div class="dorpDown">
<div class="wrapper"> 
<a href="/xwzx/gsxw/">公司新闻</a> 
<a href="/xwzx/xydt/">行业动态</a> 
<a href="/xwzx/cjwt/">常见问题</a> 
</div>
</div>
</li>
<li mark='6' px='8'> 
<a href="/gywm/qyjs/">关于我们</a>
<div class="dorpDown">
<div class="wrapper"> 
<a href="/gywm/qyjs/">企业介绍</a> 
<a href="/gywm/jytd/">精英团队</a> 
<a href="/gywm/gshj/">公司环境</a> 
<a href="/gywm/ryzz/">荣誉资质</a> 
<a href="/gywm/hzhb/">合作伙伴</a> 
<a href="/gywm/lxwm/">联系我们</a> 
</div>
</div>
</li>
<li mark='12' px='9'> 
<a href="/gywm/lxwm/">联系我们</a> 
</li>
</ul>
</div>
</div>


<script type="text/javascript">
var sid = '4,7';
headinit(sid);
</script> 


<!-- end nav --> 

<!--mub02InpageBanner-->
<div class="linkUsBanner mub01InpageBannerr" title="[!--class.name--]" style="background: url(/static/image/ece0b7cbeca53dd1.jpg) no-repeat center top;"> </div>
<!-- mub02MainContent -->
<div class="mub01MainContent"> 
<!-- 面包屑 -->
<div class="mub01address">
<div class="container">
<div class="con clearfix">
<p class="p1"> <img src="/static/picture/mub01address_icon01.png" width="13" height="18" alt="位置"> <span> <em>您的位置：[!--newsnav--] </p>
</div>
</div>
</div>
<!-- 分类 -->
<div class="newsListMenu">
<ul class="clearfix">

<? @sys_ShowClassByTemp('selfinfo',7,0,0);?>

</ul>
</div>
<!-- newsList --> 
<!-- newsListCon -->
<div class="newsListCon">
<div class="mainCon">
<div class="conBox">
<div class="con">

[!--empirenews.listtemp--]
<!--list.var1-->
[!--empirenews.listtemp--]

</div>

[!--show.listpage--]

</div>
</div>
</div>
</div>

<!--尾部开始-->

<div class="footer">
<div class="wrapper">
<div class="foot-menu">
<dl>
<dt>
<a href="javascript:;">科技服务</a>
</dt>

<?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsLoopBq(1,4,0,0,'','newstime ASC');
if($ecms_bq_sql){
while($bqr=$empire->fetch($ecms_bq_sql)){
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
<dd><a href="<?=$bqsr['titleurl']?>"><?=$bqr['title']?></a></dd>
<?php
}
}
?>

</dl>
<dl>
<dt>
<a href="javascript:;">体系认证</a>
</dt>
<?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsLoopBq(3,4,0,0,'','newstime ASC');
if($ecms_bq_sql){
while($bqr=$empire->fetch($ecms_bq_sql)){
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
<dd><a href="<?=$bqsr['titleurl']?>"><?=$bqr['title']?></a></dd>
<?php
}
}
?>
</dl>
<dl>
<dt>
<a href="/gywm/qyjs/">知识产权</a>
</dt>
<?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsLoopBq(2,4,0,0,'','newstime ASC');
if($ecms_bq_sql){
while($bqr=$empire->fetch($ecms_bq_sql)){
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
<dd><a href="<?=$bqsr['titleurl']?>"><?=$bqr['title']?></a></dd>
<?php
}
}
?>
</dl>
</div>
<div class="foot-QR"> <img src="/static/picture/25086c2a9fdafb5c.jpg" alt="精诚合创高新技术企业认定微信扫码咨询"> <span>微信扫码咨询</span> </div>
<div class="foot-tel">
<dl>
<dt>全国免费热线：</dt>
<dd>
<?=$public_r[fwrx]?>
</dd>
</dl>
<dl>
<dt>精诚合创营销专线：</dt>
<dd>
<?=$public_r[lxdh]?>
</dd>
</dl>
</div>
</div>
</div>

<div class="copyright">
<div class="wrapper">
<div class="fl"> 

<a href="/gywm/qyjs/">企业介绍</a>
 
<a href="/gywm/lxwm/">联系我们</a>
 
<a href="/gywm/hzhb/">合作伙伴</a>
 
<a href="/xwzx/cjwt/">常见问题</a>

<a href="javascript:;">网站地图</a>


</div>
<div class="fr"> Copyright © 2028 <?=$public_r[sitename]?>，<a href="https://beian.miit.gov.cn/" rel="nofollow"><?=$public_r[icp]?></a>
， 技术支持:<a href="https://www.shunking.cn/">舜王科技</a>
 
</div>
</div>
</div>


<!-- 客服2 -->
<div class="y-kefu-box y-kefu-box02">
<div class="online-service"> <i class="icon"></i>
<p>在线<br>
客服</p>
<div class="online-service-infos more-infos"> <b class="right"> <i class="right-arrow1"></i> <i class="right-arrow2"></i> </b>
<div class="part01"> <i class="icon"></i>
<p>在线客服</p>
<span>服务时间：9：00-18：00</span> </div>
<div class="part02">
<ul class="clearfix" id="onlineKf">
<li>
<a href="javascript:;" title="点击这里给我发消息" rel="nofollow"><i class="icon"></i>客服小知</a>

</li>
</ul>
</div>
</div>
</div>
<div class="kf-mobile"> <i class="icon"></i>
<p>客服<br>
热线</p>
<div class="kf-mobile-infos more-infos"> <b class="right"> <i class="right-arrow1"></i> <i class="right-arrow2"></i> </b>
<div class="cont"> <i class="icon"></i>
<p>
<?=$public_r[fwrx]?>
</p>
<span>7*24小时客服服务热线</span> </div>
</div>
</div>
<div class="kf-weChat"> <i class="icon"></i>
<p>关注<br>
微信</p>
<div class="kf-weChat-infos more-infos"> <b class="right"> <i class="right-arrow1"></i> <i class="right-arrow2"></i> </b> <img src="/static/picture/6a68b8be71dc3846.png" alt="二维码">
<p>扫一扫，关注我们</p>
</div>
</div>
<div class="back-top" id="yBackTop"> <i class="icon"></i>
<p>回到<br>
顶部</p>
</div>
</div>
<script type="text/javascript">
$('.kf-mobile, .kf-weChat, .online-service').hover(function(){
$(this).children('div').stop().show().animate({right:'70px',opacity:1}, 400);
},function(){
$(this).children('div').stop().animate({right:'90px',opacity:0}, 400,function(){$(this).hide()});
})

//返回顶部
var yWin = $(window).scrollTop();
var isShow = true;
$(window).scroll(function(){
yWin = $(window).scrollTop();
console.log(yWin);
if(yWin > 500){
if(isShow){
isShow = false;
$('#yBackTop').show().animate({left:'0'}, 400);
} 
}
if(yWin < 500){
if(!isShow){
isShow = true;
$('#yBackTop').animate({left:'55px'}, 400,function(){$(this).hide();});
}
}
})
$('#yBackTop').on('click',function(){
$('html,body').animate({'scrollTop':0}, 800);
})
</script> 


<!--尾部结束-->

</body>
</html>