<?php
if(!defined('InEmpireCMS'))
{
	exit();
}
?><!DOCTYPE html>
<html>
<head>
<meta name="renderer" content="webkit">
<meta name="force-rendering" content="webkit">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title><?=$grpagetitle?> - <?=$public_r[sitename]?></title>
<meta name="keywords" content="<?=$ecms_gr[keyboard]?>">
<meta name="description" content="<?=$grpagetitle?>">
<link href="/static/css/Common.css" rel="stylesheet" type="text/css">
<link href="/static/css/Style.css" rel="stylesheet" type="text/css">
<link href="/static/css/fancybox.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="/static/js/1.9.1jquery.min.js"></script>
<script type="text/javascript" src="/static/js/common.js"></script>
<script type="text/javascript" src="/static/js/inpage.js"></script>
</head>

<body>

<!-- header --> 

<div class="top-wrap">
<div class="wrapper">
<div class="top-menu">
<ul>
<li>
<a href="javascript:;">网站地图</a></li>
<li>
<a href="javascript:addBookmark()">收藏本站</a></li>
<li>
<a href="/gywm/lxwm/">联系方式</a></li>
</ul>
</div>
<div class="welcome">欢迎来到<?=$public_r[sitename]?>官方网站！</div>
</div>
</div>


<div class="header-wrap">
<div class="wrapper">
<div class="logo"> 
<a href="/" title="精诚合创"> <img src="/static/picture/9fe2f40936d1bb78.jpg" alt="精诚合创"> </a> </div>
<div class="slogan">
<h2>高新企业认定服务商</h2>
<p>更擅长处理疑难项目</p>
</div>
<div class="tel">
<dl>
<dt>全国服务热线</dt>
<dd>
<?=$public_r[fwrx]?>
</dd>
</dl>
</div>
</div>
</div>


<div class="nav" id="nav">
<div class="wrapper">
<ul class="nav-list" id="navBox">
<li>
<a href="/">网站首页</a></li>
<li mark='1' px='2'> 
<a href="javascript:;">科技服务</a>
<div class="dorpDown">
<div class="wrapper"> 
<a href="javascript:;">国家高新企业认定</a> 
<a href="javascript:;">成都高新技术企业认定</a> 
<a href="javascript:;">高新技术企业入库培育</a> 
</div>
</div>
</li>
<li mark='2' px='3'> 
<a href="javascript:;">知识产权</a>
<div class="dorpDown">
<div class="wrapper"> 
<a href="javascript:;">专利申请</a> 
<a href="javascript:;">版权登记</a> 
<a href="javascript:;">财税服务</a> 
<a href="javascript:;">商标注册</a> 
</div>
</div>
</li>
<li mark='3' px='4'> 
<a href="javascript:;">体系认证</a>
<div class="dorpDown">
<div class="wrapper"> 
<a href="javascript:;">知识产权贯标</a> 
<a href="javascript:;">常规项目补贴 </a> 
<a href="javascript:;">高新补贴</a> 
<a href="javascript:;">人才补贴</a> 
<a href="javascript:;">设备补贴</a> 
<a href="javascript:;">贷款补贴</a> 
<a href="javascript:;">信息平台补贴</a> 
<a href="javascript:;">其他政府资助</a> 
</div>
</div>
</li>
<li mark='5' px='6'> 
<a href="/khjz/cgal/">客户见证</a>
<div class="dorpDown">
<div class="wrapper"> 
<a href="/khjz/khpj/">客户评价</a> 
<a href="/khjz/cgal/">成功案例</a> 
</div>
</div>
</li>
<li mark='4' px='7'> 
<a href="/xwzx/">新闻中心</a>
<div class="dorpDown">
<div class="wrapper"> 
<a href="/xwzx/gsxw/">公司新闻</a> 
<a href="/xwzx/xydt/">行业动态</a> 
<a href="/xwzx/cjwt/">常见问题</a> 
</div>
</div>
</li>
<li mark='6' px='8'> 
<a href="/gywm/qyjs/">关于我们</a>
<div class="dorpDown">
<div class="wrapper"> 
<a href="/gywm/qyjs/">企业介绍</a> 
<a href="/gywm/jytd/">精英团队</a> 
<a href="/gywm/gshj/">公司环境</a> 
<a href="/gywm/gshj/">荣誉资质</a> 
<a href="/gywm/gshj/">合作伙伴</a> 
<a href="/gywm/lxwm/">联系我们</a> 
</div>
</div>
</li>
<li mark='12' px='9'> 
<a href="/gywm/lxwm/">联系我们</a> 
</li>
</ul>
</div>
</div>


<script type="text/javascript">
var sid = ',<?=$ecms_gr[classid]?>';
headinit(sid);
</script> 


<!-- end nav --> 

<!--mub02InpageBanner-->
<div class="linkUsBanner mub01InpageBannerr" title="<?=$class_r[$ecms_gr[classid]][classname]?>" style="background: url(/static/image/f1a96e828759762c.jpg) no-repeat center top;"> </div>
<!-- mub01MainContent -->
<div class="mub01MainContent" id="mub01MainContent"> 
<!-- 面包屑-->
<div class="mub01address">
<div class="container">
<div class="con clearfix">
<p class="p1"> <img src="/static/picture/mub01address_icon01.png" width="13" height="18" alt="位置"> <span> <em>您的位置：<?=$grurl?> </p>
</div>
</div>
</div>
<!-- 关于我们-->
<div class="aboutMenu" id="aboutMenulxwm">
<ul class="clearfix">

<? @sys_ShowClassByTemp('selfinfo',7,0,0);?>

</ul>
</div>

<!-- linkUsMap -->
<div class="linkUsMap">
<div class="container">
<div class="mainCon clearfix">
<div class="conL" style="background-color: rgb(248, 248, 248);">
<h3><span style="color: #006cff;"><?=$public_r[sitename]?></span></h3>
<div class="box">
<ul class=" list-paddingleft-2">
<li>
<div><img src="/static/picture/8c3e86f93be035bf.png"></div>
<p>服务热线：<em><?=$public_r[fwrx]?></em></p>
</li>
<li>
<div><img src="/static/picture/ac8beb7480ff5123.png"></div>
<p>手机号码：<em><?=$public_r[lxdh]?></em></p>
</li>
<li>
<div><img src="/static/picture/a8fecc8ac6a5cd7.png"></div>
<p>电子邮箱：<em><?=$public_r[kfyx]?></em></p>
</li>
<li>
<div><img src="/static/picture/993cd24e447b976d.png"></div>
<p>QQ号码：<em><?=$public_r[kfqq]?></em></p>
</li>
<li>
<div><img src="/static/picture/9b1de5694bdd2ad.png"></div>
<p>项目部地址<em style="white-space: normal; background-color: rgb(248, 248, 248);">（总部）</em>：<em><?=$public_r[gsdz]?></em></p>
</li>
<li>
<div><img src="/static/picture/3dc73a48a123c997.png"></div>
<p>网络部地址<em style="white-space: normal; background-color: rgb(248, 248, 248);">（分部）</em>：<em>成都市青羊区顺城大街248号（B-1503）</em></p>
</li>
</ul>
</div>
</div>
<div class="conR">
<iframe class="ueditor_baidumap" src="show.html#center=114.300532,22.390757&zoom=10&width=596&height=546&markers=113.867001,22.587491&markerStyles=l,A" width="600" height="550" frameborder="0"></iframe>
</div>
</div>
</div>
</div>
<!-- linkUsLy-->
<div class="linkUsLy">
<div class="container">
<div class="mainCon">
<div class="title">
<h3>在线留言</h3>
<p>Online message</p>
</div>
<div class="box">
<input type="text" value="您的姓名" class="input1" onfocus="if(this.value=='您的姓名'){this.value=''}" onblur="if(this.value==''){this.value='您的姓名'}" id="txtContact">
<input type="text" value="您的电话" class="input2" onfocus="if(this.value=='您的电话'){this.value=''}" onblur="if(this.value==''){this.value='您的电话'}" id="txtMobile">
<textarea onfocus="if(this.value=='留言内容'){this.value=''}" onblur="if(this.value==''){this.value='留言内容'}" id="txtShortDesc">留言内容</textarea>
<li class="yzm clearfix">
<label> 验证码： </label>
<input type="text" value="请填写验证码" onfocus="if(this.value=='请填写验证码'){this.value=''}" onblur="if(this.value==''){this.value='请填写验证码'}" runat="server" id="txtVerCode" class="iptTxt" maxlength="8">
<cite> <span id="spVerCode"></span> <span id="spVerCodeMsg" class="hd"></span> <a id="spChgVerCode" class="p hd" href="###" onclick="changeVerCode()">看不清？</a> </cite> </li>
<a href="javascript:void(0);" title="提交留言" onclick="SendLeaveword(this);" class="tj">提交留言</a> </div>
</div>
</div>
</div>
</div>

<!--尾部开始-->

<div class="footer">
<div class="wrapper">
<div class="foot-menu">
<dl>
<dt>
<a href="javascript:;" target="_blank">政府补贴</a></dt>
<dd>
<a href="javascript:;" target="_blank">知识产权贯标</a></dd>
<dd>
<a href="javascript:;" target="_blank">常规项目补贴 </a></dd>
<dd>
<a href="javascript:;" target="_blank">高新补贴</a></dd>
<dd>
<a href="javascript:;" target="_blank">人才补贴</a></dd>
</dl>
<dl>
<dt>
<a href="javascript:;" target="_blank">高新企业认定</a></dt>
<dd>
<a href="javascript:;" target="_blank">国家高新企业认定</a></dd>
<dd>
<a href="javascript:;" target="_blank">成都高新技术企业认定</a></dd>
<dd>
<a href="javascript:;" target="_blank">高新技术企业入库培育</a></dd>
</dl>
<dl>
<dt>
<a href="/gywm/qyjs/" target="_blank">关于我们</a></dt>
<dd>
<a href="/gywm/qyjs/" target="_blank">企业介绍</a></dd>
<dd>
<a href="/gywm/jytd/" target="_blank">精英团队</a></dd>
<dd>
<a href="/gywm/gshj/" target="_blank">公司环境</a></dd>
<dd>
<a href="/gywm/ryzz/" target="_blank">荣誉资质</a></dd>
</dl>
</div>
<div class="foot-QR"> <img src="/static/picture/25086c2a9fdafb5c.jpg" alt="精诚合创高新技术企业认定微信扫码咨询"> <span>微信扫码咨询</span> </div>
<div class="foot-tel">
<dl>
<dt>全国免费热线：</dt>
<dd>
<?=$public_r[fwrx]?>
</dd>
</dl>
<dl>
<dt>精诚合创私人电话：</dt>
<dd>
<?=$public_r[lxdh]?>
</dd>
</dl>
</div>
</div>
</div>

<div class="copyright">
<div class="wrapper">
<div class="fl"> 
<a href="javascript:;" target="_blank">网站地图</a> 
<a href="/gywm/lxwm/" target="_blank">联系我们</a> 
<a href="/gywm/hzhb/" target="_blank">合作伙伴</a> 
<a href="javascript:;" target="_blank">热门标签</a>
</div>
<div class="fr"> Copyright © 2028 <?=$public_r[sitename]?>，备案号：<a href="https://beian.miit.gov.cn/" target="_blank" rel="nofollow"><?=$public_r[icp]?></a>， 技术支持:<a href="https://www.shunking.cn/" target="_blank">舜王科技</a> 
</div>
</div>
</div>


<!-- 客服2 -->
<div class="y-kefu-box y-kefu-box02">
<div class="online-service"> <i class="icon"></i>
<p>在线<br>
客服</p>
<div class="online-service-infos more-infos"> <b class="right"> <i class="right-arrow1"></i> <i class="right-arrow2"></i> </b>
<div class="part01"> <i class="icon"></i>
<p>在线客服</p>
<span>服务时间：9：00-18：00</span> </div>
<div class="part02">
<ul class="clearfix" id="onlineKf">
<li>
<a href="javascript:;" target="_blank" title="点击这里给我发消息" rel="nofollow"><i class="icon"></i>客服小知</a>
</li>
</ul>
</div>
</div>
</div>
<div class="kf-mobile"> <i class="icon"></i>
<p>客服<br>
热线</p>
<div class="kf-mobile-infos more-infos"> <b class="right"> <i class="right-arrow1"></i> <i class="right-arrow2"></i> </b>
<div class="cont"> <i class="icon"></i>
<p>
<?=$public_r[fwrx]?>
</p>
<span>7*24小时客服服务热线</span> </div>
</div>
</div>
<div class="kf-weChat"> <i class="icon"></i>
<p>关注<br>
微信</p>
<div class="kf-weChat-infos more-infos"> <b class="right"> <i class="right-arrow1"></i> <i class="right-arrow2"></i> </b> <img src="/static/picture/6a68b8be71dc3846.png" alt="二维码">
<p>扫一扫，关注我们</p>
</div>
</div>
<div class="back-top" id="yBackTop"> <i class="icon"></i>
<p>回到<br>
顶部</p>
</div>
</div>
<script type="text/javascript">
$('.kf-mobile, .kf-weChat, .online-service').hover(function(){
$(this).children('div').stop().show().animate({right:'70px',opacity:1}, 400);
},function(){
$(this).children('div').stop().animate({right:'90px',opacity:0}, 400,function(){$(this).hide()});
})

//返回顶部
var yWin = $(window).scrollTop();
var isShow = true;
$(window).scroll(function(){
yWin = $(window).scrollTop();
console.log(yWin);
if(yWin > 500){
if(isShow){
isShow = false;
$('#yBackTop').show().animate({left:'0'}, 400);
} 
}
if(yWin < 500){
if(!isShow){
isShow = true;
$('#yBackTop').animate({left:'55px'}, 400,function(){$(this).hide();});
}
}
})
$('#yBackTop').on('click',function(){
$('html,body').animate({'scrollTop':0}, 800);
})
</script> 


<!--尾部结束-->

</body>
</html>
