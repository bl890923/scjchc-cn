<?php
if(!defined('InEmpireCMS'))
{
	exit();
}
?>【通用一级栏目模板】