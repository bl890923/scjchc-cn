<?php
if(!defined('InEmpireCMS'))
{
	exit();
}
?><!DOCTYPE html>
<html>
<head>
<meta name="renderer" content="webkit">
<meta name="force-rendering" content="webkit">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title><?=$grpagetitle?> - <?=$public_r[sitename]?></title>
<meta name="keywords" content="<?=$ecms_gr[keyboard]?>">
<meta name="description" content="<?=$grpagetitle?>">
<link href="/static/css/Common.css" rel="stylesheet" type="text/css">
<link href="/static/css/Style.css" rel="stylesheet" type="text/css">
<link href="/static/css/fancybox.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="/static/js/1.9.1jquery.min.js"></script>
<script type="text/javascript" src="/static/js/common.js"></script>
<script type="text/javascript" src="/static/js/inpage.js"></script>
</head>

<body>

<!-- header --> 

<div class="top-wrap">
<div class="wrapper">
<div class="top-menu">
<ul>
<li>
<a href="javascript:;">网站地图</a></li>
<li>
<a href="javascript:addBookmark()">收藏本站</a></li>
<li>
<a href="/gywm/lxwm/">联系方式</a></li>
</ul>
</div>
<div class="welcome">欢迎来到<?=$public_r[sitename]?>官方网站！</div>
</div>
</div>


<div class="header-wrap">
<div class="wrapper">
<div class="logo"> 
<a href="/" title="精诚合创"> <img src="/static/picture/logo.png" alt="精诚合创"> </a> </div>
<div class="slogan">
<h2>高新企业认定服务商</h2>
<p>更擅长处理疑难项目</p>
</div>
<div class="tel">
<dl>
<dt>全国服务热线</dt>
<dd>
<?=$public_r[fwrx]?>
</dd>
</dl>
</div>
</div>
</div>


<div class="nav" id="nav">
<div class="wrapper">
<ul class="nav-list" id="navBox">
<li>
<a href="/">网站首页</a></li>
<li mark='1' px='2'> 
<a href="javascript:;">科技服务</a>
<div class="dorpDown">
<div class="wrapper"> 
<?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsLoopBq(1,20,0,0,'','newstime ASC');
if($ecms_bq_sql){
while($bqr=$empire->fetch($ecms_bq_sql)){
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
<a href="<?=$bqsr['titleurl']?>"><?=$bqr['title']?></a>
<?php
}
}
?>
</div>
</div>
</li>
<li mark='2' px='3'> 
<a href="javascript:;">知识产权</a>
<div class="dorpDown">
<div class="wrapper"> 
<?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsLoopBq(2,20,0,0,'','newstime ASC');
if($ecms_bq_sql){
while($bqr=$empire->fetch($ecms_bq_sql)){
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
<a href="<?=$bqsr['titleurl']?>"><?=$bqr['title']?></a>
<?php
}
}
?>
</div>
</div>
</li>
<li mark='3' px='4'> 
<a href="javascript:;">体系认证</a>
<div class="dorpDown">
<div class="wrapper"> 
<?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsLoopBq(3,5,0,0,'','newstime ASC');
if($ecms_bq_sql){
while($bqr=$empire->fetch($ecms_bq_sql)){
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
<a href="<?=$bqsr['titleurl']?>"><?=$bqr['title']?></a>
<?php
}
}
?>
</div>
</div>
</li>
<li mark='5' px='6'> 
<a href="/khjz/cgal/">客户见证</a>
<div class="dorpDown">
<div class="wrapper"> 
<a href="/khjz/khpj/">客户评价</a> 
<a href="/khjz/cgal/">成功案例</a> 
</div>
</div>
</li>
<li mark='4' px='7'> 
<a href="/xwzx/">新闻中心</a>
<div class="dorpDown">
<div class="wrapper"> 
<a href="/xwzx/gsxw/">公司新闻</a> 
<a href="/xwzx/xydt/">行业动态</a> 
<a href="/xwzx/cjwt/">常见问题</a> 
</div>
</div>
</li>
<li mark='6' px='8'> 
<a href="/gywm/qyjs/">关于我们</a>
<div class="dorpDown">
<div class="wrapper"> 
<a href="/gywm/qyjs/">企业介绍</a> 
<a href="/gywm/jytd/">精英团队</a> 
<a href="/gywm/gshj/">公司环境</a> 
<a href="/gywm/ryzz/">荣誉资质</a> 
<a href="/gywm/hzhb/">合作伙伴</a> 
<a href="/gywm/lxwm/">联系我们</a> 
</div>
</div>
</li>
<li mark='12' px='9'> 
<a href="/gywm/lxwm/">联系我们</a> 
</li>
</ul>
</div>
</div>


<script type="text/javascript">
var sid = '4,7';
headinit(sid);
</script> 
 

<!-- end nav --> 

<!--mub01InpageBanner-->
<div class="aboutBanner mub01InpageBannerr" title="关于精诚合创" style="background: url(/static/image/2dccc1d3855489b.jpg) no-repeat center top;"> </div>
<!-- mub01MainContent -->
<div class="mub01MainContent"> 
<!-- 面包屑-->
<div class="mub01address">
<div class="container">
<div class="con clearfix">
<p class="p1"> <img src="/static/picture/mub01address_icon01.png" width="13" height="18" alt="位置"> <span> <em>您的位置：<?=$grurl?> </p>
</div>
</div>
</div>
<!-- 关于我们-->
<div class="aboutMenu">
<ul class="clearfix">

<? @sys_ShowClassByTemp('selfinfo',7,0,0);?>

</ul>
</div>
<!-- aboutIntro -->
<div class="aboutIntro">
<div class="container">
<div class="mub01Title">
<h3><i class="xianL"></i>公司<em>简介</em><i class="xianR"></i></h3>
</div>
<div class="mainCon">
<table width="1200px">
<tbody>
<tr class="firstRow">
<td style="word-break: break-all;" width="50%" valign="top"><div class="guanyuzhi" style="width: 580px;height: 411px;background: #ebf3f5;position: absolute;overflow: hidden;"><img src="/static/picture/85fb505e994eb054.jpg" style="width: 561px;height: 391px;overflow: hidden;/*! margin: ; */position: relative;margin-top: 10px;margin-left: 10px;" _src="/upload/images/2020/1/85fb505e994eb054.jpg" title="精诚合创" alt="精诚合创"></div></td>
<td colspan="1" rowspan="1" width="1%" valign="top"><br></td>
<td style="word-break: break-all;" width="379" valign="middle" align="left">


<p style="margin-bottom: 15px; line-height: 2em; text-indent: 0em; text-align: left;">


&nbsp;
<?=$public_r[sitename]?>
是经国家知识产权部门授权，为广大客户提供全方位的高新技术企业认证、政府项目申报、双软认证、知识产权服务的机构。尤其擅长处理疑难领域的项目申报。</p>
<p style="margin-bottom: 15px; text-align: left; line-height: 2em; text-indent: 0em;">&nbsp; 公司拥有实战经验丰富的项目团队，项目团队成员是各领域的专业人员，不仅具有坚实的理论基础和良好的操作技巧，而且具有非常丰富的从业经验和职业背景，在众多项目申报、知识产权服务领域中都有着自己独到。</p>
<p style="margin-bottom: 15px; line-height: 2em; text-indent: 0em; text-align: left;">&nbsp; 公司的经营理念是：诚信、守真，服务、迅速，公司尊崇“踏实、拼搏、责任”的企业精神，并以诚信、共赢、开创经营理念，创造良好的企业环境，以全新的管理模式，完善的技术，周到的服务品质为生存根本，我们始终坚持用户至上用心服务于客户，坚持用自己的服务去打动客户。</p>
<p style="margin-bottom: 5px; line-height: 2em; text-indent: 0em; text-align: left;">&nbsp; 我公司立足于专业的服务水准、标准化的流程、一站式的服务，长期致力于为广大企业提供优质专业服务。</p>


</td>
</tr>
</tbody>
</table>
</div>
</div>
</div>

<!-- 服务 -->
<div class="service">
<div class="wrapper">
<div class="wrap-title">
<p>项目申报需要其他资质怎么办？</p>
<h2>精诚合创一站式配套服务帮你<strong>全部解决</strong></h2>
</div>
<div class="service-list"> 
<a class="item"> <i><img src="/static/picture/f5a6beae574433c9.png" alt="版权登记"></i> <span>版权登记</span>
<p>理清财务账目，快速通过高新</p>
</a> <a class="item"> <i><img src="/static/picture/de9ce0ddf13341f7.png" alt="专利申请"></i> <span>专利申请</span>
<p>快速申请，满足高新条件</p>
</a> <a class="item"> <i><img src="/static/picture/2ebab77d8d83d572.png" alt="财税服务"></i> <span>财税服务</span>
<p>理清财务账目，快速通过高新</p>
</a> <a class="item"> <i><img src="/static/picture/a03cd69924b32a24.png" alt="商标注册"></i> <span>商标注册</span>
<p>多位资深法律顾问为您服务</p>
</a> <a class="item"> <i><img src="/static/picture/690011ed35bcb46b.png" alt="其他补贴"></i> <span>其他补贴</span>
<p>发现更多政府支持政策</p>
</a> </div>
</div>
</div>
<!-- end 服务 --> 

<!-- 精英团队 -->
<div class="team">
<div class="wrapper">
<div class="wrap-title white">
<h2><a href="/gywm/jytd/"><strong>精诚合创精英团队</strong></a></h2>
<p>解决了70多个疑难项目</p>
</div>
<div class="team-slide">
<div class="team-list">
<div class="bd">
<div class="team-item">
<div class="leftCon">
<div class="pic"> <a href="/gywm/jytd/" title="赵子扬"><img src="/static/picture/af67e6108ffd406d.jpg" alt="赵子扬"></a> </div>
<div class="text"> <a href="/gywm/jytd/" rel="nofollow">找他<br>
咨询</a> <strong>赵子扬</strong>
<p>多年认证经验</p>
</div>
</div>
<div class="rightCon">
<div class="tit">TA解决的疑难项目</div>
<div class="text">
<dl>
<dt><a href="javascript:;">成都市***实业有限公司</a></dt>
<dd><a href="javascript:;">梳理中发现，该公司科技成果转化项得分很低，科技成果转化附件材料混乱、装订无序，与成果转化汇总表中所列不一致，拉低整体分数，导致未顺利通过。</a></dd>
</dl>
<dl>
<dt><a href="javascript:;">成都市***宁科技有限公司</a></dt>
<dd><a href="javascript:;">参考第一次申报评分，以及第一次申报的具体材料，发现此前申报中，写资料的人没抓住核心技术，对企业核心产品理解不到位，表述有偏差，最终导致未通过。</a></dd>
</dl>
<dl>
<dt><a href="javascript:;">成都市***网络科技有限公司</a></dt>
<dd><a href="javascript:;">该公司第一次递交未通过，后经精诚合创梳理发现，高新领域选择错误，导致一系列反应。而且分析后财务数据填写亦有误，资料不相符，最终导致评分较低。</a></dd>
</dl>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<!-- end 精英团队 --> 

<!-- 合作机构 -->
<div class="partner">
<div class="wrapper">
<div class="wrap-title">
<h2><a href="/gywm/hzhb/"><b>与多个机构合作，让申报流程</b><strong>更顺畅</strong></a></h2>
<p>精诚合创，更擅长成都本地科技项目申报</p>
</div>
<div class="partner-list">
<ul>

<?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsLoopBq(11,10,0,1);
if($ecms_bq_sql){
while($bqr=$empire->fetch($ecms_bq_sql)){
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
<li>
<div class="pic"> <a href="/gywm/hzhb/" title="<?=$bqr['title']?>"> <img src="<?=$bqr['titlepic']?>" alt="<?=$bqr['title']?>"> </a> </div>
<div class="text"><a href="/gywm/hzhb/"><?=$bqr['title']?></a></div>
</li>
<?php
}
}
?>


</ul>
</div>
</div>
</div>
<!-- end 合作机构 --> 

<!-- aboutMien 企业风采 -->
<div class="aboutMien">
<div class="mub01Title"> <a href="/gywm/gshj/">
<h3><i class="xianL"></i>公司<em>环境</em><i class="xianR"></i></h3>
</a> </div>
<div class="gshj-slider"> <span class="prev"></span> <span class="next"></span>
<div id="carousel">

<?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsLoopBq(9,4,0,1);
if($ecms_bq_sql){
while($bqr=$empire->fetch($ecms_bq_sql)){
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
<div class="item"> <a href="/gywm/gshj/"><img src="<?=$bqr['titlepic']?>" alt=""><?=$bqr['title']?></a> <span><?=$bqr['title']?></span> </div>
<?php
}
}
?>

</div>
</div>
</div>
</div>
<script type="text/javascript" src="/static/js/jquery.carouFredSel-6.0.4-packed.js"></script> 
<script type="text/javascript">
function openItem( $item ) {
$item.addClass( 'cur' );
$item.stop().animate({
height: 450
});
}

$(function() {
$('#carousel').carouFredSel({
circular: true,
infinite: true,
width: '100%',
height: 450,
items: 3,
auto: true,
prev: '.gshj-slider .prev',
next: '.gshj-slider .next',
scroll: {
items: 1,
duration: 1000,
easing: 'quadratic',
onBefore: function( data ) {
data.items.old.removeClass( 'cur' );
data.items.old.stop().animate({
height: 450
});
},
onAfter: function( data ) {
openItem( data.items.visible.eq( 1 ) );
}
},
onCreate: function( data ) {
openItem( data.items.eq( 1 ) );
}
});
});
</script> 
<script>
mswMove("aboutHonor", "aboutHonorBtn01", "aboutHonorBtn02", "", true, "left", true, 310, 1000, 3000, 4);
</script> 


<!--尾部开始-->

<div class="footer">
<div class="wrapper">
<div class="foot-menu">
<dl>
<dt>
<a href="javascript:;">科技服务</a>
</dt>

<?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsLoopBq(1,4,0,0,'','newstime ASC');
if($ecms_bq_sql){
while($bqr=$empire->fetch($ecms_bq_sql)){
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
<dd><a href="<?=$bqsr['titleurl']?>"><?=$bqr['title']?></a></dd>
<?php
}
}
?>

</dl>
<dl>
<dt>
<a href="javascript:;">体系认证</a>
</dt>
<?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsLoopBq(3,4,0,0,'','newstime ASC');
if($ecms_bq_sql){
while($bqr=$empire->fetch($ecms_bq_sql)){
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
<dd><a href="<?=$bqsr['titleurl']?>"><?=$bqr['title']?></a></dd>
<?php
}
}
?>
</dl>
<dl>
<dt>
<a href="/gywm/qyjs/">知识产权</a>
</dt>
<?php
$bqno=0;
$ecms_bq_sql=sys_ReturnEcmsLoopBq(2,4,0,0,'','newstime ASC');
if($ecms_bq_sql){
while($bqr=$empire->fetch($ecms_bq_sql)){
$bqsr=sys_ReturnEcmsLoopStext($bqr);
$bqno++;
?>
<dd><a href="<?=$bqsr['titleurl']?>"><?=$bqr['title']?></a></dd>
<?php
}
}
?>
</dl>
</div>
<div class="foot-QR"> <img src="/static/picture/25086c2a9fdafb5c.jpg" alt="精诚合创高新技术企业认定微信扫码咨询"> <span>微信扫码咨询</span> </div>
<div class="foot-tel">
<dl>
<dt>全国免费热线：</dt>
<dd>
<?=$public_r[fwrx]?>
</dd>
</dl>
<dl>
<dt>精诚合创营销专线：</dt>
<dd>
<?=$public_r[lxdh]?>
</dd>
</dl>
</div>
</div>
</div>

<div class="copyright">
<div class="wrapper">
<div class="fl"> 

<a href="/gywm/qyjs/">企业介绍</a>
 
<a href="/gywm/lxwm/">联系我们</a>
 
<a href="/gywm/hzhb/">合作伙伴</a>
 
<a href="/xwzx/cjwt/">常见问题</a>

<a href="javascript:;">网站地图</a>


</div>
<div class="fr"> Copyright © 2028 <?=$public_r[sitename]?>，<a href="https://beian.miit.gov.cn/" rel="nofollow"><?=$public_r[icp]?></a>
， 技术支持:<a href="https://www.shunking.cn/">舜王科技</a>
 
</div>
</div>
</div>


<!-- 客服2 -->
<div class="y-kefu-box y-kefu-box02">
<div class="online-service"> <i class="icon"></i>
<p>在线<br>
客服</p>
<div class="online-service-infos more-infos"> <b class="right"> <i class="right-arrow1"></i> <i class="right-arrow2"></i> </b>
<div class="part01"> <i class="icon"></i>
<p>在线客服</p>
<span>服务时间：9：00-18：00</span> </div>
<div class="part02">
<ul class="clearfix" id="onlineKf">
<li>
<a href="javascript:;" title="点击这里给我发消息" rel="nofollow"><i class="icon"></i>客服小知</a>

</li>
</ul>
</div>
</div>
</div>
<div class="kf-mobile"> <i class="icon"></i>
<p>客服<br>
热线</p>
<div class="kf-mobile-infos more-infos"> <b class="right"> <i class="right-arrow1"></i> <i class="right-arrow2"></i> </b>
<div class="cont"> <i class="icon"></i>
<p>
<?=$public_r[fwrx]?>
</p>
<span>7*24小时客服服务热线</span> </div>
</div>
</div>
<div class="kf-weChat"> <i class="icon"></i>
<p>关注<br>
微信</p>
<div class="kf-weChat-infos more-infos"> <b class="right"> <i class="right-arrow1"></i> <i class="right-arrow2"></i> </b> <img src="/static/picture/6a68b8be71dc3846.png" alt="二维码">
<p>扫一扫，关注我们</p>
</div>
</div>
<div class="back-top" id="yBackTop"> <i class="icon"></i>
<p>回到<br>
顶部</p>
</div>
</div>
<script type="text/javascript">
$('.kf-mobile, .kf-weChat, .online-service').hover(function(){
$(this).children('div').stop().show().animate({right:'70px',opacity:1}, 400);
},function(){
$(this).children('div').stop().animate({right:'90px',opacity:0}, 400,function(){$(this).hide()});
})

//返回顶部
var yWin = $(window).scrollTop();
var isShow = true;
$(window).scroll(function(){
yWin = $(window).scrollTop();
console.log(yWin);
if(yWin > 500){
if(isShow){
isShow = false;
$('#yBackTop').show().animate({left:'0'}, 400);
} 
}
if(yWin < 500){
if(!isShow){
isShow = true;
$('#yBackTop').animate({left:'55px'}, 400,function(){$(this).hide();});
}
}
})
$('#yBackTop').on('click',function(){
$('html,body').animate({'scrollTop':0}, 800);
})
</script> 


<!--尾部结束-->

</body>
</html>
