<?php
@include("../../inc/header.php");

/*
		SoftName : EmpireBak
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

E_D("DROP TABLE IF EXISTS `jchc_enewslog`;");
E_C("CREATE TABLE `jchc_enewslog` (
  `loginid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(30) NOT NULL DEFAULT '',
  `logintime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `loginip` varchar(20) NOT NULL DEFAULT '',
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `password` varchar(30) NOT NULL DEFAULT '',
  `loginauth` tinyint(1) NOT NULL DEFAULT '0',
  `ipport` varchar(6) NOT NULL DEFAULT '',
  PRIMARY KEY (`loginid`),
  KEY `status` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8");
E_D("replace into `jchc_enewslog` values('1',0x61646d696e,'2022-07-08 01:17:36',0x3232322e3231302e38372e3636,'1','','0',0x3634373030);");
E_D("replace into `jchc_enewslog` values('2',0x61646d696e,'2022-07-08 09:24:08',0x3138322e3133382e3232362e313333,'1','','0',0x3530333131);");

@include("../../inc/footer.php");
?>