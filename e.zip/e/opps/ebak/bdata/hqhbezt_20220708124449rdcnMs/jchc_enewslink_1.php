<?php
@include("../../inc/header.php");

/*
		SoftName : EmpireBak
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

E_D("DROP TABLE IF EXISTS `jchc_enewslink`;");
E_C("CREATE TABLE `jchc_enewslink` (
  `lid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `lname` varchar(100) NOT NULL DEFAULT '',
  `lpic` varchar(255) NOT NULL DEFAULT '',
  `lurl` varchar(255) NOT NULL DEFAULT '',
  `ltime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `onclick` int(11) NOT NULL DEFAULT '0',
  `width` varchar(10) NOT NULL DEFAULT '',
  `height` varchar(10) NOT NULL DEFAULT '',
  `target` varchar(10) NOT NULL DEFAULT '',
  `myorder` tinyint(4) NOT NULL DEFAULT '0',
  `email` varchar(60) NOT NULL DEFAULT '',
  `lsay` text NOT NULL,
  `checked` tinyint(1) NOT NULL DEFAULT '0',
  `ltype` smallint(6) NOT NULL DEFAULT '0',
  `classid` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`lid`),
  KEY `classid` (`classid`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8");
E_D("replace into `jchc_enewslink` values('1',0xe8889ce78e8be7a791e68a80,'',0x68747470733a2f2f7777772e7368756e6b696e672e636e,'2022-07-08 09:46:19','0','','',0x5f626c616e6b,'0','','','1','0','0');");
E_D("replace into `jchc_enewslink` values('2',0xe8889ce78e8be9809ae4bfa1,'',0x687474703a2f2f7777772e737774782e7368756e6b696e672e636e,'2022-07-08 09:46:34','0','','',0x5f626c616e6b,'0','','','1','0','0');");
E_D("replace into `jchc_enewslink` values('3',0xe8889ce78e8be5bda9e58db0,'',0x687474703a2f2f7777772e737763792e7368756e6b696e672e636e,'2022-07-08 09:46:47','0','','',0x5f626c616e6b,'0','','','1','0','0');");
E_D("replace into `jchc_enewslink` values('4',0xe8889ce78e8be5bbbae7ab99,'',0x68747470732f2f7777772e736974652e7368756e6b696e672e636e,'2022-07-08 09:47:07','0','','',0x5f626c616e6b,'0','','','1','0','0');");
E_D("replace into `jchc_enewslink` values('5',0xe9809fe8b5a2e5bbbae7ab99,'',0x687474703a2f2f7777772e736f6f6e77696e2e746f70,'2022-07-08 09:47:21','0','','',0x5f626c616e6b,'0','','','1','0','0');");
E_D("replace into `jchc_enewslink` values('6',0xe68890e983bde5b882e7a791e68a80e5b180,'',0x687474703a2f2f,'2022-07-08 09:47:37','0','','',0x5f626c616e6b,'0','','','1','0','0');");
E_D("replace into `jchc_enewslink` values('7',0xe59b9be5b79de79c81e7a791e68a80e58e85,'',0x687474703a2f2f,'2022-07-08 09:47:43','0','','',0x5f626c616e6b,'0','','','1','0','0');");

@include("../../inc/footer.php");
?>