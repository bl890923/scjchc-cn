<?php
@include("../../inc/header.php");

/*
		SoftName : EmpireBak
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

E_D("DROP TABLE IF EXISTS `jchc_enewsbqtemp`;");
E_C("CREATE TABLE `jchc_enewsbqtemp` (
  `tempid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `tempname` varchar(60) NOT NULL DEFAULT '',
  `modid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `temptext` text NOT NULL,
  `showdate` varchar(50) NOT NULL DEFAULT '',
  `listvar` text NOT NULL,
  `subnews` smallint(5) unsigned NOT NULL DEFAULT '0',
  `rownum` smallint(5) unsigned NOT NULL DEFAULT '0',
  `classid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `docode` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`tempid`),
  KEY `classid` (`classid`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8");
E_D("replace into `jchc_enewsbqtemp` values('1',0xe5ad90e6a08fe79baee5afbce888aae6a087e7adbee6a8a1e69dbf,'1',0x7c205b212d2d656d706972656e6577732e6c69737474656d702d2d5d3c212d2d6c6973742e766172312d2d3e5b212d2d656d706972656e6577732e6c69737474656d702d2d5d,0x592d6d2d6420483a693a73,0x3c6120687265663d5c225b212d2d636c61737375726c2d2d5d5c223e5b212d2d636c6173736e616d652d2d5d3c2f613e207c20,'0','1','0','0');");
E_D("replace into `jchc_enewsbqtemp` values('7',0xe5beaae78eafe5ad90e6a08fe79baee6a087e7adbe,'1',0x5b212d2d656d706972656e6577732e6c69737474656d702d2d5d0d0a3c212d2d6c6973742e766172312d2d3e0d0a5b212d2d656d706972656e6577732e6c69737474656d702d2d5d0d0a,0x592d6d2d64,0x3c6c693e3c6120687265663d5c225b212d2d636c61737375726c2d2d5d5c223e5b212d2d636c6173736e616d652d2d5d3c2f613e3c2f6c693e0d0a,'0','1','0','0');");
E_D("replace into `jchc_enewsbqtemp` values('12',0xe6a08fe79bae74616273e5afbce888aa,'1',0x5b212d2d656d706972656e6577732e6c69737474656d702d2d5d3c212d2d6c6973742e766172312d2d3e5b212d2d656d706972656e6577732e6c69737474656d702d2d5d,0x592d6d2d6420483a693a73,0x3c6c692069643d227461626e61765f62746e5f5b212d2d6e6f2d2d5d22206f6e6d6f7573656f7665723d227461626974287468697329223e3c6120687265663d225b212d2d636c61737375726c2d2d5d223e5b212d2d636c6173736e616d652d2d5d3c2f613e3c2f6c693e,'0','1','0','0');");

@include("../../inc/footer.php");
?>