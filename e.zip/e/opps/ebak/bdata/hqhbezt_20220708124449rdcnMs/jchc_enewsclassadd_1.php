<?php
@include("../../inc/header.php");

/*
		SoftName : EmpireBak
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

E_D("DROP TABLE IF EXISTS `jchc_enewsclassadd`;");
E_C("CREATE TABLE `jchc_enewsclassadd` (
  `classid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `classtext` mediumtext NOT NULL,
  `ttids` text NOT NULL,
  `eclasspagetext` mediumtext NOT NULL,
  PRIMARY KEY (`classid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8");
E_D("replace into `jchc_enewsclassadd` values('1','','','');");
E_D("replace into `jchc_enewsclassadd` values('2','','','');");
E_D("replace into `jchc_enewsclassadd` values('3','','','');");
E_D("replace into `jchc_enewsclassadd` values('4','','','');");
E_D("replace into `jchc_enewsclassadd` values('5',0x3c21444f43545950452068746d6c205055424c4943205c222d2f2f5733432f2f445444205848544d4c20312e30205472616e736974696f6e616c2f2f454e5c22205c22687474703a2f2f7777772e77332e6f72672f54522f7868746d6c312f4454442f7868746d6c312d7472616e736974696f6e616c2e6474645c223e0d0a3c68746d6c20786d6c6e733d5c22687474703a2f2f7777772e77332e6f72672f313939392f7868746d6c5c223e0d0a3c686561643e0d0a3c6d65746120687474702d65717569763d5c22436f6e74656e742d547970655c2220636f6e74656e743d5c22746578742f68746d6c3b20636861727365743d7574662d385c22202f3e0d0a3c6d65746120687474702d65717569763d5c22726566726573685c2220636f6e74656e743d5c22303b75726c3d2f6b686a7a2f6367616c2f5c223e0d0a3c2f686561643e0d0a3c2f68746d6c3e,'','');");
E_D("replace into `jchc_enewsclassadd` values('6',0x3c21444f43545950452068746d6c205055424c4943205c222d2f2f5733432f2f445444205848544d4c20312e30205472616e736974696f6e616c2f2f454e5c22205c22687474703a2f2f7777772e77332e6f72672f54522f7868746d6c312f4454442f7868746d6c312d7472616e736974696f6e616c2e6474645c223e0d0a3c68746d6c20786d6c6e733d5c22687474703a2f2f7777772e77332e6f72672f313939392f7868746d6c5c223e0d0a3c686561643e0d0a3c6d65746120687474702d65717569763d5c22436f6e74656e742d547970655c2220636f6e74656e743d5c22746578742f68746d6c3b20636861727365743d7574662d385c22202f3e0d0a3c6d65746120687474702d65717569763d5c22726566726573685c2220636f6e74656e743d5c22303b75726c3d2f6779776d2f71796a732f5c223e0d0a3c2f686561643e0d0a3c2f68746d6c3e,'','');");
E_D("replace into `jchc_enewsclassadd` values('7','','','');");
E_D("replace into `jchc_enewsclassadd` values('8','','','');");
E_D("replace into `jchc_enewsclassadd` values('9','','','');");
E_D("replace into `jchc_enewsclassadd` values('10','','','');");
E_D("replace into `jchc_enewsclassadd` values('11','','','');");
E_D("replace into `jchc_enewsclassadd` values('12','','','');");
E_D("replace into `jchc_enewsclassadd` values('13','','','');");
E_D("replace into `jchc_enewsclassadd` values('14','','','');");
E_D("replace into `jchc_enewsclassadd` values('15','','','');");
E_D("replace into `jchc_enewsclassadd` values('16','','','');");
E_D("replace into `jchc_enewsclassadd` values('17','','','');");

@include("../../inc/footer.php");
?>