<?php
@include("../../inc/header.php");

/*
		SoftName : EmpireBak
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

E_D("DROP TABLE IF EXISTS `jchc_ecms_news_index`;");
E_C("CREATE TABLE `jchc_ecms_news_index` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `classid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `checked` tinyint(1) NOT NULL DEFAULT '0',
  `newstime` int(10) unsigned NOT NULL DEFAULT '0',
  `truetime` int(10) unsigned NOT NULL DEFAULT '0',
  `lastdotime` int(10) unsigned NOT NULL DEFAULT '0',
  `havehtml` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `classid` (`classid`),
  KEY `checked` (`checked`),
  KEY `newstime` (`newstime`),
  KEY `truetime` (`truetime`,`id`),
  KEY `havehtml` (`classid`,`truetime`,`havehtml`,`checked`,`id`)
) ENGINE=MyISAM AUTO_INCREMENT=126 DEFAULT CHARSET=utf8");
E_D("replace into `jchc_ecms_news_index` values('1','7','1','1657222077','1657222092','1657222092','1');");
E_D("replace into `jchc_ecms_news_index` values('2','12','1','1657222119','1657222141','1657222141','1');");
E_D("replace into `jchc_ecms_news_index` values('3','1','1','1657246906','1657246934','1657246934','1');");
E_D("replace into `jchc_ecms_news_index` values('4','1','1','1657246936','1657246960','1657246960','1');");
E_D("replace into `jchc_ecms_news_index` values('5','1','1','1657246962','1657246980','1657246980','1');");
E_D("replace into `jchc_ecms_news_index` values('6','1','1','1657246982','1657246995','1657246995','1');");
E_D("replace into `jchc_ecms_news_index` values('7','1','1','1657246998','1657247021','1657247021','1');");
E_D("replace into `jchc_ecms_news_index` values('8','1','1','1657247024','1657247046','1657247046','1');");
E_D("replace into `jchc_ecms_news_index` values('9','1','1','1657247054','1657247065','1657247065','1');");
E_D("replace into `jchc_ecms_news_index` values('10','2','1','1657247715','1657247732','1657247732','1');");
E_D("replace into `jchc_ecms_news_index` values('11','2','1','1657247735','1657247752','1657247752','1');");
E_D("replace into `jchc_ecms_news_index` values('12','2','1','1657247755','1657247773','1657247773','1');");
E_D("replace into `jchc_ecms_news_index` values('13','3','1','1657247788','1657247818','1657247818','1');");
E_D("replace into `jchc_ecms_news_index` values('14','3','1','1657247824','1657247840','1657247840','1');");
E_D("replace into `jchc_ecms_news_index` values('15','3','1','1657247843','1657247856','1657247856','1');");
E_D("replace into `jchc_ecms_news_index` values('16','3','1','1657247859','1657247870','1657247870','1');");
E_D("replace into `jchc_ecms_news_index` values('17','3','1','1657247872','1657247885','1657247885','1');");
E_D("replace into `jchc_ecms_news_index` values('18','3','1','1657247888','1657247897','1657247897','1');");
E_D("replace into `jchc_ecms_news_index` values('19','3','1','1657247900','1657247918','1657247918','1');");
E_D("replace into `jchc_ecms_news_index` values('20','16','1','1657249218','1657249218','1657249218','1');");
E_D("replace into `jchc_ecms_news_index` values('21','16','1','1657249218','1657249218','1657249218','1');");
E_D("replace into `jchc_ecms_news_index` values('22','16','1','1657249219','1657249219','1657249219','1');");
E_D("replace into `jchc_ecms_news_index` values('23','16','1','1657249219','1657249219','1657249219','1');");
E_D("replace into `jchc_ecms_news_index` values('24','16','1','1657249221','1657249221','1657249221','1');");
E_D("replace into `jchc_ecms_news_index` values('25','16','1','1657249221','1657249221','1657249221','1');");
E_D("replace into `jchc_ecms_news_index` values('26','16','1','1657249222','1657249222','1657249222','1');");
E_D("replace into `jchc_ecms_news_index` values('27','16','1','1657249222','1657249222','1657249222','1');");
E_D("replace into `jchc_ecms_news_index` values('28','16','1','1657249223','1657249223','1657249223','1');");
E_D("replace into `jchc_ecms_news_index` values('29','16','1','1657249223','1657249223','1657249223','1');");
E_D("replace into `jchc_ecms_news_index` values('30','16','1','1657249225','1657249225','1657249225','1');");
E_D("replace into `jchc_ecms_news_index` values('31','16','1','1657249225','1657249225','1657249225','1');");
E_D("replace into `jchc_ecms_news_index` values('32','16','1','1657249226','1657249226','1657249226','1');");
E_D("replace into `jchc_ecms_news_index` values('33','16','1','1657249226','1657249226','1657249226','1');");
E_D("replace into `jchc_ecms_news_index` values('34','16','1','1657249227','1657249227','1657249227','1');");
E_D("replace into `jchc_ecms_news_index` values('35','16','1','1657249227','1657249227','1657249227','1');");
E_D("replace into `jchc_ecms_news_index` values('36','16','1','1657249229','1657249229','1657249229','1');");
E_D("replace into `jchc_ecms_news_index` values('37','16','1','1657249229','1657249229','1657249229','1');");
E_D("replace into `jchc_ecms_news_index` values('38','16','1','1657249230','1657249230','1657249230','1');");
E_D("replace into `jchc_ecms_news_index` values('39','16','1','1657249230','1657249230','1657249230','1');");
E_D("replace into `jchc_ecms_news_index` values('40','16','1','1657249231','1657249231','1657249231','1');");
E_D("replace into `jchc_ecms_news_index` values('41','16','1','1657249231','1657249231','1657249231','1');");
E_D("replace into `jchc_ecms_news_index` values('42','16','1','1657249233','1657249233','1657249233','1');");
E_D("replace into `jchc_ecms_news_index` values('43','16','1','1657249233','1657249233','1657249233','1');");
E_D("replace into `jchc_ecms_news_index` values('44','16','1','1657249234','1657249234','1657249234','1');");
E_D("replace into `jchc_ecms_news_index` values('45','16','1','1657249234','1657249234','1657249234','1');");
E_D("replace into `jchc_ecms_news_index` values('46','16','1','1657249236','1657249236','1657249236','1');");
E_D("replace into `jchc_ecms_news_index` values('47','16','1','1657249236','1657249236','1657249236','1');");
E_D("replace into `jchc_ecms_news_index` values('48','16','1','1657249237','1657249237','1657249237','1');");
E_D("replace into `jchc_ecms_news_index` values('49','16','1','1657249237','1657249237','1657249237','1');");
E_D("replace into `jchc_ecms_news_index` values('50','16','1','1657249238','1657249238','1657249238','1');");
E_D("replace into `jchc_ecms_news_index` values('51','16','1','1657249238','1657249238','1657249238','1');");
E_D("replace into `jchc_ecms_news_index` values('52','16','1','1657249240','1657249240','1657249240','1');");
E_D("replace into `jchc_ecms_news_index` values('53','16','1','1657249240','1657249240','1657249240','1');");
E_D("replace into `jchc_ecms_news_index` values('54','16','1','1657249241','1657249241','1657249241','1');");
E_D("replace into `jchc_ecms_news_index` values('55','16','1','1657249241','1657249241','1657249241','1');");
E_D("replace into `jchc_ecms_news_index` values('56','16','1','1657249242','1657249242','1657249242','1');");
E_D("replace into `jchc_ecms_news_index` values('57','16','1','1657249242','1657249242','1657249242','1');");
E_D("replace into `jchc_ecms_news_index` values('58','16','1','1657249244','1657249244','1657249244','1');");
E_D("replace into `jchc_ecms_news_index` values('59','16','1','1657249244','1657249244','1657249244','1');");
E_D("replace into `jchc_ecms_news_index` values('60','16','1','1657249245','1657249245','1657249245','1');");
E_D("replace into `jchc_ecms_news_index` values('61','16','1','1657249245','1657249245','1657249245','1');");
E_D("replace into `jchc_ecms_news_index` values('62','16','1','1657249246','1657249246','1657249246','1');");
E_D("replace into `jchc_ecms_news_index` values('63','16','1','1657249246','1657249246','1657249246','1');");
E_D("replace into `jchc_ecms_news_index` values('64','16','1','1657249248','1657249248','1657249248','1');");
E_D("replace into `jchc_ecms_news_index` values('65','16','1','1657249248','1657249248','1657249248','1');");
E_D("replace into `jchc_ecms_news_index` values('66','16','1','1657249249','1657249249','1657249249','1');");
E_D("replace into `jchc_ecms_news_index` values('67','17','1','1657249249','1657249249','1657249249','1');");
E_D("replace into `jchc_ecms_news_index` values('68','17','1','1657249250','1657249250','1657249250','1');");
E_D("replace into `jchc_ecms_news_index` values('69','16','1','1657249250','1657249250','1657249250','1');");
E_D("replace into `jchc_ecms_news_index` values('70','17','1','1657249252','1657249252','1657249252','1');");
E_D("replace into `jchc_ecms_news_index` values('71','17','1','1657249252','1657249252','1657249252','1');");
E_D("replace into `jchc_ecms_news_index` values('72','15','1','1657249253','1657249253','1657249253','1');");
E_D("replace into `jchc_ecms_news_index` values('73','15','1','1657249253','1657249253','1657249253','1');");
E_D("replace into `jchc_ecms_news_index` values('74','15','1','1657249255','1657249255','1657249255','1');");
E_D("replace into `jchc_ecms_news_index` values('75','17','1','1657249255','1657249255','1657249255','1');");
E_D("replace into `jchc_ecms_news_index` values('76','15','1','1657249256','1657249256','1657249256','1');");
E_D("replace into `jchc_ecms_news_index` values('77','16','1','1657249256','1657249256','1657249256','1');");
E_D("replace into `jchc_ecms_news_index` values('78','17','1','1657249257','1657249257','1657249257','1');");
E_D("replace into `jchc_ecms_news_index` values('79','16','1','1657249257','1657249257','1657249257','1');");
E_D("replace into `jchc_ecms_news_index` values('80','16','1','1657249259','1657249259','1657249259','1');");
E_D("replace into `jchc_ecms_news_index` values('81','16','1','1657249259','1657249259','1657249259','1');");
E_D("replace into `jchc_ecms_news_index` values('82','16','1','1657249260','1657249260','1657249260','1');");
E_D("replace into `jchc_ecms_news_index` values('83','16','1','1657249260','1657249260','1657249260','1');");
E_D("replace into `jchc_ecms_news_index` values('84','16','1','1657249261','1657249261','1657249261','1');");
E_D("replace into `jchc_ecms_news_index` values('85','17','1','1657249261','1657249261','1657249261','1');");
E_D("replace into `jchc_ecms_news_index` values('86','17','1','1657249263','1657249263','1657249263','1');");
E_D("replace into `jchc_ecms_news_index` values('87','16','1','1657249263','1657249263','1657249263','1');");
E_D("replace into `jchc_ecms_news_index` values('88','16','1','1657249264','1657249264','1657249264','1');");
E_D("replace into `jchc_ecms_news_index` values('89','16','1','1657249264','1657249264','1657249264','1');");
E_D("replace into `jchc_ecms_news_index` values('90','16','1','1657249265','1657249265','1657249265','1');");
E_D("replace into `jchc_ecms_news_index` values('91','16','1','1657249265','1657249265','1657249265','1');");
E_D("replace into `jchc_ecms_news_index` values('92','16','1','1657249267','1657249267','1657249267','1');");
E_D("replace into `jchc_ecms_news_index` values('93','16','1','1657249267','1657249267','1657249267','1');");
E_D("replace into `jchc_ecms_news_index` values('94','16','1','1657249268','1657249268','1657249268','1');");
E_D("replace into `jchc_ecms_news_index` values('95','16','1','1657249268','1657249268','1657249268','1');");
E_D("replace into `jchc_ecms_news_index` values('96','15','1','1657249270','1657249270','1657251661','1');");
E_D("replace into `jchc_ecms_news_index` values('97','16','1','1657249270','1657249270','1657249270','1');");
E_D("replace into `jchc_ecms_news_index` values('98','16','1','1657249271','1657249271','1657249271','1');");
E_D("replace into `jchc_ecms_news_index` values('99','15','1','1657249271','1657249271','1657249271','1');");
E_D("replace into `jchc_ecms_news_index` values('100','16','1','1657249272','1657249272','1657249272','1');");
E_D("replace into `jchc_ecms_news_index` values('101','16','1','1657249272','1657249272','1657249272','1');");
E_D("replace into `jchc_ecms_news_index` values('102','11','1','1657252051','1657252072','1657252072','1');");
E_D("replace into `jchc_ecms_news_index` values('103','11','1','1657252075','1657252087','1657252087','1');");
E_D("replace into `jchc_ecms_news_index` values('104','11','1','1657252089','1657252098','1657252098','1');");
E_D("replace into `jchc_ecms_news_index` values('105','11','1','1657252101','1657252127','1657252127','1');");
E_D("replace into `jchc_ecms_news_index` values('106','11','1','1657252456','1657252462','1657252462','1');");
E_D("replace into `jchc_ecms_news_index` values('107','11','1','1657252465','1657252582','1657252582','1');");
E_D("replace into `jchc_ecms_news_index` values('108','11','1','1657252585','1657252725','1657252725','1');");
E_D("replace into `jchc_ecms_news_index` values('109','11','1','1657252727','1657252861','1657252861','1');");
E_D("replace into `jchc_ecms_news_index` values('110','11','1','1657252940','1657252946','1657252946','1');");
E_D("replace into `jchc_ecms_news_index` values('111','11','1','1657253019','1657253040','1657253040','1');");
E_D("replace into `jchc_ecms_news_index` values('112','13','1','1657253075','1657253426','1657253426','1');");
E_D("replace into `jchc_ecms_news_index` values('113','13','1','1657253430','1657253489','1657253489','1');");
E_D("replace into `jchc_ecms_news_index` values('114','13','1','1657253491','1657253528','1657253528','1');");
E_D("replace into `jchc_ecms_news_index` values('115','13','1','1657253532','1657253569','1657253569','1');");
E_D("replace into `jchc_ecms_news_index` values('116','13','1','1657253573','1657253604','1657253604','1');");
E_D("replace into `jchc_ecms_news_index` values('117','13','1','1657253608','1657253634','1657253634','1');");
E_D("replace into `jchc_ecms_news_index` values('118','9','1','1657254862','1657254884','1657254884','1');");
E_D("replace into `jchc_ecms_news_index` values('119','9','1','1657254888','1657254908','1657254908','1');");
E_D("replace into `jchc_ecms_news_index` values('120','9','1','1657254912','1657254917','1657254917','1');");
E_D("replace into `jchc_ecms_news_index` values('121','9','1','1657254919','1657254928','1657254928','1');");
E_D("replace into `jchc_ecms_news_index` values('122','8','1','1657255060','1657255107','1657255107','1');");
E_D("replace into `jchc_ecms_news_index` values('123','8','1','1657255060','1657255116','1657255116','1');");
E_D("replace into `jchc_ecms_news_index` values('124','8','1','1657255060','1657255123','1657255123','1');");
E_D("replace into `jchc_ecms_news_index` values('125','8','1','1657255060','1657255123','1657255123','1');");

@include("../../inc/footer.php");
?>