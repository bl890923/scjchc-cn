<?php
@include("../../inc/header.php");

/*
		SoftName : EmpireBak
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

E_D("DROP TABLE IF EXISTS `jchc_enewsclass`;");
E_C("CREATE TABLE `jchc_enewsclass` (
  `classid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `bclassid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `classname` varchar(50) NOT NULL DEFAULT '',
  `sonclass` text NOT NULL,
  `is_zt` tinyint(1) NOT NULL DEFAULT '0',
  `lencord` smallint(6) NOT NULL DEFAULT '0',
  `link_num` tinyint(4) NOT NULL DEFAULT '0',
  `newstempid` smallint(6) NOT NULL DEFAULT '0',
  `onclick` int(11) NOT NULL DEFAULT '0',
  `listtempid` smallint(6) NOT NULL DEFAULT '0',
  `featherclass` text NOT NULL,
  `islast` tinyint(1) NOT NULL DEFAULT '0',
  `classpath` text NOT NULL,
  `classtype` varchar(10) NOT NULL DEFAULT '',
  `newspath` varchar(20) NOT NULL DEFAULT '',
  `filename` tinyint(1) NOT NULL DEFAULT '0',
  `filetype` varchar(10) NOT NULL DEFAULT '',
  `openpl` tinyint(1) NOT NULL DEFAULT '0',
  `openadd` tinyint(1) NOT NULL DEFAULT '0',
  `newline` int(11) NOT NULL DEFAULT '0',
  `hotline` int(11) NOT NULL DEFAULT '0',
  `goodline` int(11) NOT NULL DEFAULT '0',
  `classurl` varchar(200) NOT NULL DEFAULT '',
  `groupid` smallint(6) NOT NULL DEFAULT '0',
  `myorder` smallint(6) NOT NULL DEFAULT '0',
  `filename_qz` varchar(20) NOT NULL DEFAULT '',
  `hotplline` tinyint(4) NOT NULL DEFAULT '0',
  `modid` smallint(6) NOT NULL DEFAULT '0',
  `checked` tinyint(1) NOT NULL DEFAULT '0',
  `firstline` tinyint(4) NOT NULL DEFAULT '0',
  `bname` varchar(50) NOT NULL DEFAULT '',
  `islist` tinyint(1) NOT NULL DEFAULT '0',
  `searchtempid` smallint(6) NOT NULL DEFAULT '0',
  `tid` smallint(6) NOT NULL DEFAULT '0',
  `tbname` varchar(60) NOT NULL DEFAULT '',
  `maxnum` int(11) NOT NULL DEFAULT '0',
  `checkpl` tinyint(1) NOT NULL DEFAULT '0',
  `down_num` tinyint(4) NOT NULL DEFAULT '0',
  `online_num` tinyint(4) NOT NULL DEFAULT '0',
  `listorder` varchar(50) NOT NULL DEFAULT '',
  `reorder` varchar(50) NOT NULL DEFAULT '',
  `intro` text NOT NULL,
  `classimg` varchar(255) NOT NULL DEFAULT '',
  `jstempid` smallint(6) NOT NULL DEFAULT '0',
  `addinfofen` int(11) NOT NULL DEFAULT '0',
  `listdt` tinyint(1) NOT NULL DEFAULT '0',
  `showclass` tinyint(1) NOT NULL DEFAULT '0',
  `showdt` tinyint(1) NOT NULL DEFAULT '0',
  `checkqadd` tinyint(1) NOT NULL DEFAULT '0',
  `qaddlist` tinyint(1) NOT NULL DEFAULT '0',
  `qaddgroupid` text NOT NULL,
  `qaddshowkey` tinyint(1) NOT NULL DEFAULT '0',
  `adminqinfo` tinyint(1) NOT NULL DEFAULT '0',
  `doctime` smallint(6) NOT NULL DEFAULT '0',
  `classpagekey` varchar(255) NOT NULL DEFAULT '',
  `dtlisttempid` smallint(6) NOT NULL DEFAULT '0',
  `classtempid` smallint(6) NOT NULL DEFAULT '0',
  `nreclass` tinyint(1) NOT NULL DEFAULT '0',
  `nreinfo` tinyint(1) NOT NULL DEFAULT '0',
  `nrejs` tinyint(1) NOT NULL DEFAULT '0',
  `nottobq` tinyint(1) NOT NULL DEFAULT '0',
  `ipath` varchar(255) NOT NULL DEFAULT '',
  `addreinfo` tinyint(1) NOT NULL DEFAULT '0',
  `haddlist` tinyint(4) NOT NULL DEFAULT '0',
  `sametitle` tinyint(1) NOT NULL DEFAULT '0',
  `definfovoteid` smallint(6) NOT NULL DEFAULT '0',
  `wburl` varchar(255) NOT NULL DEFAULT '',
  `qeditchecked` tinyint(1) NOT NULL DEFAULT '0',
  `wapstyleid` smallint(6) NOT NULL DEFAULT '0',
  `repreinfo` tinyint(1) NOT NULL DEFAULT '0',
  `pltempid` smallint(6) NOT NULL DEFAULT '0',
  `cgroupid` text NOT NULL,
  `yhid` smallint(6) NOT NULL DEFAULT '0',
  `wfid` smallint(6) NOT NULL DEFAULT '0',
  `cgtoinfo` tinyint(1) NOT NULL DEFAULT '0',
  `bdinfoid` varchar(25) NOT NULL DEFAULT '',
  `repagenum` smallint(5) unsigned NOT NULL DEFAULT '0',
  `keycid` smallint(6) NOT NULL DEFAULT '0',
  `allinfos` int(10) unsigned NOT NULL DEFAULT '0',
  `infos` int(10) unsigned NOT NULL DEFAULT '0',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `oneinfo` tinyint(1) NOT NULL DEFAULT '0',
  `addsql` varchar(255) NOT NULL DEFAULT '',
  `wapislist` tinyint(1) NOT NULL DEFAULT '0',
  `fclast` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`classid`),
  KEY `bclassid` (`bclassid`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8");
E_D("replace into `jchc_enewsclass` values('1','0',0xe7a791e68a80e69c8de58aa1,'','0','25','0','2','0','2','','1',0x6b6a6677,0x2e68746d6c,'','0',0x2e68746d6c,'0','0','0','0','0','','0','0','','0','1','1','0',0xe7a791e68a80e69c8de58aa1,'1','0','1',0x6e657773,'0','0','1','1',0x69642044455343,0x6e65777374696d652044455343,'','','0','0','0','0','0','0','0','','0','0','0','','2','1','0','0','0','0','','1','0','0','0','','0','0','0','0','','0','0','0','','0','0','7','7','1657215190','0','','0','1657221832');");
E_D("replace into `jchc_enewsclass` values('2','0',0xe79fa5e8af86e4baa7e69d83,'','0','25','0','2','0','2','','1',0x7a736371,0x2e68746d6c,'','0',0x2e68746d6c,'0','0','0','0','0','','0','0','','0','1','1','0',0xe79fa5e8af86e4baa7e69d83,'1','0','1',0x6e657773,'0','0','1','1',0x69642044455343,0x6e65777374696d652044455343,'','','0','0','0','0','0','0','0','','0','0','0','','2','1','0','0','0','0','','1','0','0','0','','0','0','0','0','','0','0','0','','0','0','3','3','1657215204','0','','0','1657221823');");
E_D("replace into `jchc_enewsclass` values('3','0',0xe4bd93e7b3bbe8aea4e8af81,'','0','25','0','2','0','2','','1',0x7478727a,0x2e68746d6c,'','0',0x2e68746d6c,'0','0','0','0','0','','0','0','','0','1','1','0',0xe4bd93e7b3bbe8aea4e8af81,'1','0','1',0x6e657773,'0','0','1','1',0x69642044455343,0x6e65777374696d652044455343,'','','0','0','0','0','0','0','0','','0','0','0','','2','1','0','0','0','0','','1','0','0','0','','0','0','0','0','','0','0','0','','0','0','7','7','1657215215','0','','0','1657221814');");
E_D("replace into `jchc_enewsclass` values('4','0',0xe696b0e997bbe4b8ade5bf83,0x7c31357c31367c31377c,'0','25','0','1','0','1','','0',0x78777a78,0x2e68746d6c,'','0',0x2e68746d6c,'0','0','0','0','0','','0','0','','0','1','1','0',0xe696b0e997bbe4b8ade5bf83,'1','0','1',0x6e657773,'0','0','1','1',0x69642044455343,0x6e65777374696d652044455343,'','','0','0','0','0','0','0','0','','0','0','0','','1','1','0','0','0','0','','1','0','0','0','','0','0','0','0','','0','0','0','','0','0','0','0','1657215226','0','','0','1657219258');");
E_D("replace into `jchc_enewsclass` values('5','0',0xe5aea2e688b7e8a781e8af81,0x7c31337c31347c,'0','25','0','1','0','1','','0',0x6b686a7a,0x2e68746d6c,'','0',0x2e68746d6c,'0','0','0','0','0','','0','0','','0','1','1','0',0xe5aea2e688b7e8a781e8af81,'2','0','1',0x6e657773,'0','0','1','1',0x69642044455343,0x6e65777374696d652044455343,'','','0','0','0','0','0','0','0','','0','0','0','','1','1','0','0','0','0','','1','0','0','0','','0','0','0','0','','0','0','0','','0','0','0','0','1657215236','0','','0','1657221791');");
E_D("replace into `jchc_enewsclass` values('6','0',0xe585b3e4ba8ee68891e4bbac,0x7c377c387c397c31307c31317c31327c,'0','25','0','1','0','1','','0',0x6779776d,0x2e68746d6c,'','0',0x2e68746d6c,'0','0','0','0','0','','0','0','','0','1','1','0',0xe585b3e4ba8ee68891e4bbac,'2','0','1',0x6e657773,'0','0','1','1',0x69642044455343,0x6e65777374696d652044455343,'','','0','0','0','0','0','0','0','','0','0','0','','1','1','0','0','0','0','','1','0','0','0','','0','0','0','0','','0','0','0','','0','0','0','0','1657215246','0','','0','1657221758');");
E_D("replace into `jchc_enewsclass` values('7','6',0xe4bc81e4b89ae4bb8be7bb8d,'','0','25','0','1','0','1',0x7c367c,'1',0x6779776d2f71796a73,0x2e68746d6c,'','0',0x2e68746d6c,'0','0','0','0','0','','0','0','','0','1','1','0',0xe4bc81e4b89ae4bb8be7bb8d,'0','0','1',0x6e657773,'0','0','1','1',0x69642044455343,0x6e65777374696d652044455343,'','','0','0','0','0','0','0','0','','0','0','0','','1','1','1','0','0','0','','1','0','0','0','','0','0','0','0','','0','0','0','','0','0','1','1','1657215343','0','','0','1657222065');");
E_D("replace into `jchc_enewsclass` values('8','6',0xe7b2bee88bb1e59ba2e9989f,'','0','25','0','1','0','4',0x7c367c,'1',0x6779776d2f6a797464,0x2e68746d6c,'','0',0x2e68746d6c,'0','0','0','0','0','','0','0','','0','2','1','0',0xe7b2bee88bb1e59ba2e9989f,'0','0','1',0x6e657773,'0','0','1','1',0x69642044455343,0x6e65777374696d652044455343,'','','0','0','0','0','0','0','0','','0','0','0','','4','1','0','1','0','0','','1','0','0','0','','0','0','0','0','','0','0','0','','0','0','4','4','1657215385','0','','0','1657255224');");
E_D("replace into `jchc_enewsclass` values('9','6',0xe585ace58fb8e78eafe5a283,'','0','25','0','1','0','3',0x7c367c,'1',0x6779776d2f6773686a,0x2e68746d6c,'','0',0x2e68746d6c,'0','0','0','0','0','','0','0','','0','2','1','0',0xe585ace58fb8e78eafe5a283,'0','0','1',0x6e657773,'0','0','1','1',0x69642044455343,0x6e65777374696d652044455343,'','','0','0','0','0','0','0','0','','0','0','0','','3','1','0','1','0','0','','1','0','0','0','','0','0','0','0','','0','0','0','','0','0','4','4','1657215396','0','','0','1657255235');");
E_D("replace into `jchc_enewsclass` values('10','6',0xe88da3e8aa89e8b584e8b4a8,'','0','25','0','1','0','3',0x7c367c,'1',0x6779776d2f72797a7a,0x2e68746d6c,'','0',0x2e68746d6c,'0','0','0','0','0','','0','0','','0','2','1','0',0xe88da3e8aa89e8b584e8b4a8,'0','0','1',0x6e657773,'0','0','1','1',0x69642044455343,0x6e65777374696d652044455343,'','','0','0','0','0','0','0','0','','0','0','0','','3','1','0','1','0','0','','1','0','0','0','','0','0','0','0','','0','0','0','','0','0','0','0','1657215407','0','','0','1657255253');");
E_D("replace into `jchc_enewsclass` values('11','6',0xe59088e4bd9ce4bc99e4bcb4,'','0','25','0','1','0','5',0x7c367c,'1',0x6779776d2f687a6862,0x2e68746d6c,'','0',0x2e68746d6c,'0','0','0','0','0','','0','0','','0','2','1','0',0xe59088e4bd9ce4bc99e4bcb4,'0','0','1',0x6e657773,'0','0','1','1',0x69642044455343,0x6e65777374696d652044455343,'','','0','0','0','0','0','0','0','','0','0','0','','5','1','0','1','0','0','','1','0','0','0','','0','0','0','0','','0','0','0','','0','0','10','10','1657215417','0','','0','1657252038');");
E_D("replace into `jchc_enewsclass` values('12','6',0xe88194e7b3bbe68891e4bbac,'','0','25','0','1','0','1',0x7c367c,'1',0x6779776d2f6c78776d,0x2e68746d6c,'','0',0x2e68746d6c,'0','0','0','0','0','','0','0','','0','1','1','0',0xe88194e7b3bbe68891e4bbac,'0','0','1',0x6e657773,'0','0','1','1',0x69642044455343,0x6e65777374696d652044455343,'','','0','0','0','0','0','0','0','','0','0','0','','1','1','1','0','0','0','','1','0','0','0','','0','0','0','0','','0','0','0','','0','0','1','1','1657215428','0','','0','1657222051');");
E_D("replace into `jchc_enewsclass` values('13','5',0xe68890e58a9fe6a188e4be8b,'','0','25','0','1','0','2',0x7c357c,'1',0x6b686a7a2f6367616c,0x2e68746d6c,'','0',0x2e68746d6c,'0','0','0','0','0','','0','0','','0','1','1','0',0xe68890e58a9fe6a188e4be8b,'0','0','1',0x6e657773,'0','0','1','1',0x69642044455343,0x6e65777374696d652044455343,'','','0','0','0','0','0','0','0','','0','0','0','','2','1','0','0','0','0','','1','0','0','0','','0','0','0','0','','0','0','0','','0','0','6','6','1657215440','0','','0','1657222328');");
E_D("replace into `jchc_enewsclass` values('14','5',0xe5aea2e688b7e8af84e4bbb7,'','0','25','0','1','0','2',0x7c357c,'1',0x6b686a7a2f6b68706a,0x2e68746d6c,'','0',0x2e68746d6c,'0','0','0','0','0','','0','0','','0','1','1','0',0xe5aea2e688b7e8af84e4bbb7,'0','0','1',0x6e657773,'0','0','1','1',0x69642044455343,0x6e65777374696d652044455343,'','','0','0','0','0','0','0','0','','0','0','0','','2','1','0','0','0','0','','1','0','0','0','','0','0','0','0','','0','0','0','','0','0','0','0','1657215453','0','','0','1657222365');");
E_D("replace into `jchc_enewsclass` values('15','4',0xe585ace58fb8e696b0e997bb,'','0','25','0','1','0','1',0x7c347c,'1',0x78777a782f67737877,0x2e68746d6c,'','0',0x2e68746d6c,'0','0','0','0','0','','0','0','','0','1','1','0',0xe585ace58fb8e696b0e997bb,'0','0','1',0x6e657773,'0','0','1','1',0x69642044455343,0x6e65777374696d652044455343,'','','0','0','0','0','0','0','0','','0','0','0','','1','1','0','0','0','0','','1','0','0','0','','0','0','0','0','','0','0','0','','0','0','6','6','1657215464','0','','0','1657215464');");
E_D("replace into `jchc_enewsclass` values('16','4',0xe8a18ce4b89ae58aa8e68081,'','0','25','0','1','0','1',0x7c347c,'1',0x78777a782f78796474,0x2e68746d6c,'','0',0x2e68746d6c,'0','0','0','0','0','','0','0','','0','1','1','0',0xe8a18ce4b89ae58aa8e68081,'0','0','1',0x6e657773,'0','0','1','1',0x69642044455343,0x6e65777374696d652044455343,'','','0','0','0','0','0','0','0','','0','0','0','','1','1','0','0','0','0','','1','0','0','0','','0','0','0','0','','0','0','0','','0','0','68','68','1657215474','0','','0','1657215474');");
E_D("replace into `jchc_enewsclass` values('17','4',0xe5b8b8e8a781e997aee9a298,'','0','25','0','1','0','1',0x7c347c,'1',0x78777a782f636a7774,0x2e68746d6c,'','0',0x2e68746d6c,'0','0','0','0','0','','0','0','','0','1','1','0',0xe5b8b8e8a781e997aee9a298,'0','0','1',0x6e657773,'0','0','1','1',0x69642044455343,0x6e65777374696d652044455343,'','','0','0','0','0','0','0','0','','0','0','0','','1','1','0','0','0','0','','1','0','0','0','','0','0','0','0','','0','0','0','','0','0','8','8','1657215506','0','','0','1657215506');");

@include("../../inc/footer.php");
?>