<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<br><br>
<font size=5>您已登录，<a href=index.php><u>点击这里</u></a>可重新登陆</font>